let internalwindow={
    create:function(config){

        
        let newWindow = id('internalwindow').cloneNode(true);
        newWindow.removeAttr('id');
        newWindow.find('.internalwindow-title').innerHTML=config.title; // set title text
        newWindow.find('.internalwindow-minimize-container').innerHTML=config.title; // set tskbar text
        

        // set  zindex
        let zindex = parseInt(newWindow.style.zIndex);
        document.querySelectorAll('.internalwindow').forEach(function(el){
            let elZindex = parseInt(el.style.zIndex);
            if(elZindex >= zindex){
                zindex = elZindex+1
            }
        });
        newWindow.style.zIndex = zindex.toString();

        // put content in new window
        if(typeof config.content.nodeName != "undefined"){
            newWindow.find('.internalwindow-container').appendChild(config.content.cloneNode(true))
        }else if(typeof config.content != "undefined"){
            newWindow.find('.internalwindow-container').innerHTML=config.content;
        }


        // append window to taskbar or document
        
        if( config.taskbar == undefined){
            document.body.appendChild(newWindow);
        }else{
            config.taskbar.appendChild(newWindow);
        }

        // before create;
        if(typeof config.onbeforeCreate == "function"){
            config.onbeforeCreate(newWindow);
        }
        
        
        // call back function
        setTimeout(function() {
            if(typeof config.callback == "function"){
                config.callback(newWindow);
            }
          }, 10);
        
        

    },
    toFront:function(element,e){
        element.style.zIndex = e.timeStamp.toFixed(0).toString();
    },
    drag:function(e,handler){
        let innerwindow=handler.parents('internalwindow')[0];
        let innerwindowX=innerwindow.offsetLeft;
        let innerwindowY=innerwindow.offsetTop;
        let firstMouseX=e.clientX;
        let firstMouseY=e.clientY;
        
        window.document.onmousemove=function(ev){
            innerwindow.find('.internalwindow-container').css({"display": "none"});
            ev.preventDefault();
            if(ev.clientX < 0 || ev.clientY < 5 || ev.clientX > window.innerWidth || ev.clientY+5 > window.innerHeight ){
                return;
            }
            let xdistance = ev.clientX - firstMouseX;
            let Ydistance = ev.clientY - firstMouseY;
          
            innerwindow.style.left = (innerwindowX + xdistance) + "px";
            innerwindow.style.top = (innerwindowY + Ydistance) + "px";
        }
        window.document.onmouseup = function(){
            window.document.onmousemove=null;
            window.document.onmouseup=null;
            innerwindow.find('.internalwindow-container').css({"display": "block"});
        }
    },
    maximize:function(handler){
        
        
       let innerwindow = handler.parents('internalwindow')[0];
       if(innerwindow.isClass('internalwindow-miniimize-mode')){
        innerwindow.removeClass('internalwindow-miniimize-mode');
        return;
       }
       
       let btn = innerwindow.find('.internalwindow-control-window .maximize-internalwindow');
       if(innerwindow.isClass('internalwindow-maximize-mode')){

            btn.addClass('fa-window-maximize');
            btn.removeClass('fa-window-restore');
            innerwindow.removeClass('internalwindow-maximize-mode');
        
       }else{
            btn.addClass('fa-window-restore');
            btn.removeClass('fa-window-maximize');
            innerwindow.addClass('internalwindow-maximize-mode');
       }
       
    },
    minimize:function(handler){
        let innerwindow = handler.parents('internalwindow')[0];
        innerwindow.addClass('internalwindow-miniimize-mode');
    },
    minimizeRestor:function(handler){
        let innerwindow = handler.parents('internalwindow')[0];
        innerwindow.removeClass('internalwindow-miniimize-mode');
    },
    close:function(handler){
        handler.parents('internalwindow')[0].delete();
    },
    resize:function(e,handler){
        let innerwindow=handler.parents('internalwindow')[0];
        let innerwindowH=innerwindow.clientHeight;
        let innerwindowW=innerwindow.clientWidth;
        let firstMouseX=e.clientX;
        let firstMouseY=e.clientY;
        let resizer=handler.getAttribute("resize");
        innerwindow.find('.internalwindow-container').css({"display": "none"});
        window.onmousemove=function(ev){
            ev.preventDefault();
            window.document.body.style.cursor=window.getComputedStyle(handler, null).getPropertyValue("cursor");
            
            let maxH=26;
            switch(resizer){
                case"left":
                    if((firstMouseX-ev.clientX)+innerwindowW>=169 && ev.clientX>=0){ 
                        innerwindow.style.width = ((firstMouseX-ev.clientX)+innerwindowW) + "px";
                        innerwindow.style.left = (ev.clientX) + "px";
                    }
                break;
                case"top":
                    if((firstMouseY-ev.clientY)+innerwindowH>=maxH && ev.clientY>=0){ 
                        innerwindow.style.height = ((firstMouseY-ev.clientY)+innerwindowH) + "px";
                        innerwindow.style.top = (ev.clientY) + "px";
                    }
                break;
                case"right":
                    if((ev.clientX-firstMouseX)+innerwindowW>=169 && ev.clientX<=window.innerWidth){ 
                        innerwindow.style.width = ((ev.clientX-firstMouseX)+innerwindowW) + "px";
                    }
                    
                break;
                case"bottom":
                    if((ev.clientY-firstMouseY)+innerwindowH>=maxH && ev.clientY<=window.innerHeight){ 
                        innerwindow.style.height = ((ev.clientY-firstMouseY)+innerwindowH) + "px";
                    }
                   
                break;
                case"topleft":
                    if((firstMouseY-ev.clientY)+innerwindowH+6>=maxH && ev.clientY>=0){ 
                        innerwindow.style.height = ((firstMouseY-ev.clientY)+innerwindowH) + "px";
                        innerwindow.style.top = (ev.clientY) + "px";
                    }

                    if((firstMouseX-ev.clientX)+innerwindowW>=169 && ev.clientX>=0){ 
                        innerwindow.style.width = ((firstMouseX-ev.clientX)+innerwindowW) + "px";
                        innerwindow.style.left = (ev.clientX) + "px";
                    }
                break;
                case"topright":
                    if((firstMouseY-ev.clientY)+innerwindowH>=maxH && ev.clientY>=0){ 
                        innerwindow.style.top = (ev.clientY) + "px";
                        innerwindow.style.height = ((firstMouseY-ev.clientY)+innerwindowH) + "px";
                    }
                    if((ev.clientX-firstMouseX)+innerwindowW>=169  && ev.clientX<=window.innerWidth){ 
                    innerwindow.style.width = ((ev.clientX-firstMouseX)+innerwindowW) + "px";
                    }
                break;
                case"bottomleft":
                    if((firstMouseX-ev.clientX)+innerwindowW>=169 && ev.clientX>=0){ 
                        innerwindow.style.left = (ev.clientX) + "px";
                        innerwindow.style.width = ((firstMouseX-ev.clientX)+innerwindowW) + "px";
                    }
                    if((ev.clientY-firstMouseY)+innerwindowH>=maxH && ev.clientY<=window.innerHeight){ 
                        innerwindow.style.height = ((ev.clientY-firstMouseY)+innerwindowH) + "px";
                    }
                break;
                case"bottomright":
                    if((ev.clientX-firstMouseX)+innerwindowW>=169 && ev.clientX<=window.innerWidth){ 
                        innerwindow.style.width = ((ev.clientX-firstMouseX)+innerwindowW) + "px";
                    }
                    if((ev.clientY-firstMouseY)+innerwindowH>=maxH  && ev.clientY<=window.innerHeight){ 
                        innerwindow.style.height = ((ev.clientY-firstMouseY)+innerwindowH) + "px";
                    }
                    
                    
                break;
            }
            
        }
        window.onmouseup = function(){ qt(); }

        function qt(){
            let maxH=26;
            if(innerwindow.clientHeight<=maxH){innerwindow.style.height=maxH+"px";}
            if(innerwindow.clientWidth<=160){innerwindow.style.width="170px";}
            if(innerwindow.clientHeight>=window.innerHeight){innerwindow.style.height=window.innerHeight+"px";}
            if(innerwindow.clientWidth>=window.innerWidth){innerwindow.style.width=window.innerWidth+"px";}
            window.onmousemove=null;
            window.onmouseup=null;
            window.document.body.style.cursor="";
            innerwindow.find('.internalwindow-container').css({"display": "block"});
        }
    }
}