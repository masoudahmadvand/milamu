var oo = {
    browserLanguage: navigator.language.slice(0, 2),
    csv: {
        parse: function () {
            for (var t = arguments[0], e = t.match(/[^\r\n]+/g), o = [], n = e[0].split(","), i = 1; i < e.length; i++) {
                for (var a = {}, r = e[i].split(","), s = 0; s < n.length; s++) isNaN(r[s]) === !1 ? a[n[s]] = Number(r[s]) : a[n[s]] = r[s];
                o.push(a)
            }
            return o
        },
        stringify: function () {
            var t = arguments[0],
                e = "";
            for (var o in t[0]) e += o + ",";
            e = e.substr(0, e.length - 1) + "\r\n";
            for (var n = 0; n <= t.length; n++) {
                var i = "";
                for (var o in t[n]) i += '"' + t[n][o] + '",';
                e += i + "\r\n"
            }
            return e
        },
        createFile: function (t, e) {
            var o = new Blob([e], {
                    type: 'text/csv;charset=UTF-8"'
                }),
                n = window.URL.createObjectURL(o),
                i = document.createElement("a");
            document.body.appendChild(i), i.style = "display: none", i.href = n, i.download = t + ".csv", i.click()
        }
    },
    xml: {
        parse: function (t) {
            
            var e = new DOMParser;
            return e.parseFromString(t, "application/xml")
        },
        stringify: function (t) {
            try {
                return (new XMLSerializer).serializeToString(t)
            } catch (e) {
                try {
                    return t.xml
                } catch (e) {
                    console.log("Xmlserializer not supported")
                }
            }
            return !1
        },
        xmlToJson : function(xml) {
            var obj = {};
            if (xml.nodeType == 1) {                
                if (xml.attributes.length > 0) {
                    obj["@attributes"] = {};
                    for (var j = 0; j < xml.attributes.length; j++) {
                        var attribute = xml.attributes.item(j);
                        obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
                    }
                }
            } else if (xml.nodeType == 3) { 
                obj = xml.nodeValue;
            }            
            if (xml.hasChildNodes()) {
                for (var i = 0; i < xml.childNodes.length; i++) {
                    var item = xml.childNodes.item(i);
                    var nodeName = item.nodeName;
                    if (typeof (obj[nodeName]) == "undefined") {
                        obj[nodeName] = xmlToJson(item);
                    } else {
                        if (typeof (obj[nodeName].push) == "undefined") {
                            var old = obj[nodeName];
                            obj[nodeName] = [];
                            obj[nodeName].push(old);
                        }
                        obj[nodeName].push(xmlToJson(item));
                    }
                }
            }
            return obj;
        },
        xmlTextToJson:function(xml){
            var regex = /(<\w+[^<]*?)\s+([\w-]+)="([^"]+)">/;
            while (xml.match(regex)) xml = xml.replace(regex, '<$2>$3</$2>$1>');  
            xml = xml.replace(/\s/g, ' ').  
            replace(/< *\?[^>]*?\? *>/g, '').  
            replace(/< *!--[^>]*?-- *>/g, '').  
            replace(/< *(\/?) *(\w[\w-]+\b):(\w[\w-]+\b)/g, '<$1$2_$3').
            replace(/< *(\w[\w-]+\b)([^>]*?)\/ *>/g, '< $1$2>').
            replace(/(\w[\w-]+\b):(\w[\w-]+\b) *= *"([^>]*?)"/g, '$1_$2="$3"').
            replace(/< *(\w[\w-]+\b)((?: *\w[\w-]+ *= *" *[^"]*?")+ *)>( *[^< ]*?\b.*?)< *\/ *\1 *>/g, '< $1$2 value="$3">').
            replace(/< *(\w[\w-]+\b) *</g, '<$1>< ').
            replace(/> *>/g, '>').
            replace(/"/g, '\\"').
            replace(/< *(\w[\w-]+\b) *>([^<>]*?)< *\/ *\1 *>/g, '"$1":"$2",').
            replace(/< *(\w[\w-]+\b) *>([^<>]*?)< *\/ *\1 *>/g, '"$1":[{$2}],').
            replace(/< *(\w[\w-]+\b) *>(?=("\w[\w-]+\b)":\{.*?\},\2)(.*?)< *\/ *\1 *>/, '"$1":{}$3},').
            replace(/],\s*?".*?": *\[/g, ',').
            replace(/< \/(\w[\w-]+\b)\},\{\1>/g, '},{').
            replace(/< *(\w[\w-]+\b)[^>]*?>/g, '"$1":{').
            replace(/< *\/ *\w[\w-]+ *>/g, '},').
            replace(/\} *,(?= *(\}|\]))/g, '}').
            replace(/] *,(?= *(\}|\]))/g, ']').
            replace(/" *,(?= *(\}|\]))/g, '"').
            replace(/ *, *$/g, '');
            xml = '{' + xml + '}';
            return xml;
        }
    },
    qstring: function (key) {
        var search = location.search;
        if (void 0 !== key) {
            var regex = new RegExp(key + "=([^&]*)"),
                results = regex.exec(search);
            return results ? results[1] : null
        }
        return search = search.replace(/=/g, '":"'), search = search.replace(/&/g, '","'), search = search.substr(1, search.length), search = 'var results={"' + search + '"}', eval(search), results
    },
    userlocation: function (t) {
        return navigator.geolocation ? navigator.geolocation.getCurrentPosition(t) : void console.error("OOFRAME : Geolocation is not supported by this browser.")
    },
    unicid: function () {
        var t = (new Date).getTime();
        return parseInt(t)
    },
    random: function () {
        var t = arguments[0],
            e = typeof t;
        switch ("[object Array]" === Object.prototype.toString.call(t) && (e = "array"), e) {
            case "array":
                return t[Math.floor(Math.random() * t.length)];
            case "object":
                var o = 0;
                for (var n in t)
                    if (Math.random() < 1 / ++o) return n;
                break;
            case "string":
                for (var i = "", a = 0; 5 > a; a++) i += t.charAt(Math.floor(Math.random() * t.length));
                return i
        }
    },
    stripTag: function () {
        return "string" == typeof arguments[0] ? arguments[0].replace(new RegExp("(<([^>]+)>)", "ig"), "") : void 0
    },
    optimaze: {
        image: function (file, callback) {

            var reader = new FileReader();

            reader.onload = function (event) {
                var img = new Image();
                img.src = event.target.result;
                img.onload = function () {
                    var canvas = document.createElement('canvas');
                    var maxW = 1920;
                    canvas.width = img.width;
                    canvas.height = img.height;
                    if (img.width > maxW) {
                        var a = 100 - ((maxW * 100) / img.width); // 1.9335937
                        canvas.height = img.height - ((a * img.height) / 100);
                        canvas.width = maxW;
                    }
                    var ctx = canvas.getContext("2d");
                    ctx.drawImage(img, 0, 0, img.width, img.height, 0, 0, canvas.width, canvas.height);
                    var imageFile = canvas.toDataURL(file.type, 0.7).replace(/^data:image\/[a-z]+;base64,/, "");
                    var imageFile64 = canvas.toDataURL(file.type, 0.7);


                    var blobBin = atob(imageFile64.split(',')[1]);
                    var temparray = [];
                    for(var i = 0; i < blobBin.length; i++) {
                        temparray.push(blobBin.charCodeAt(i));
                    }
                    var opfile=new Blob([new Uint8Array(temparray)], {type: file.type});
                    opfile.lastModifiedDate = new Date();
                    opfile['oldSize']=file.size;
                    opfile['name']=file.name;

                    callback(imageFile,imageFile64,opfile);
                }
            }

            reader.readAsDataURL(file);
        }
    },
    toggleFullScreen: function () {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen();
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            }
        }
    },
    bytesToSize:function (bytes) {
        var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        if (bytes == 0) return 'n/a';
        var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
        if (i == 0) return bytes + ' ' + sizes[i];
        return (bytes / Math.pow(1024, i)).toFixed(1) + ' ' + sizes[i];
    }
};

var ajx={
    post: function (config) {
        var xhr = new XMLHttpRequest();
        if(config.progress !=undefined){config.progress(xhr);}
         // satatus
         xhr.onreadystatechange = function (e) {
            if (typeof config.statechange === "function") {
                config.statechange(xhr.readyState,xhr,config);
            }
            if (this.readyState === 4 && this.status === 200) {
                switch (xhr.getResponseHeader("Content-Type")) {
                    case 'application/json':
                        config.callback(JSON.parse(xhr.responseText),xhr);
                        break;
                    default:
                        config.callback(xhr.responseText,xhr);
                        break;
                }
            }
        }

        var async ; if(config.async===undefined && typeof config.async !=="boolean"){async = true}else{async = config.async} ;
        // initializes a newly-created request
        xhr.open("POST",config.url, async);
        // set headers
        for (var key in config.head) {
            xhr.setRequestHeader(key, config.head[key]);
        }
        if(config.params==undefined){config.params={}};
        // send request
        xhr.send(JSON.stringify(config.params));
    },
    get: function (config) {
        var xhr = new XMLHttpRequest();
        if(config.progress !=undefined){config.progress(xhr);}
        
        // satatus
        xhr.onreadystatechange = function (e) {
            if (typeof config.statechange === "function") {
                config.statechange(xhr.readyState,xhr,config);
            }
            if (this.readyState === 4 && this.status === 200) {
                
                switch (xhr.getResponseHeader("Content-Type")) {
                    case 'application/json':
                        config.callback(JSON.parse(xhr.responseText),xhr);
                        break;
                    default:
                        config.callback(xhr.responseText,xhr);
                        break;
                }
                
            }
        }
        
        // set parameters
        config.url += "?";
        for (var key in config.params) {
            config.url += key + "=" + encodeURIComponent(config.params[key]) + "&";
        }
        config.url = config.url.substring(0, config.url.length - 1);

        var async ; if(config.async===undefined && typeof config.async !=="boolean"){async = true}else{async = config.async} ;
        // initializes a newly-created request
        xhr.open("GET",config.url,async);
        // set headers
        for (var key in config.head) {
            xhr.setRequestHeader(key, config.head[key]);
        }
        

        // send request
        xhr.send();

    }
};

// selectors

function id(selector) {
    return document.getElementById(selector);
}

function qs(selector) {
    return document.querySelector(selector);
}

function qsa(selector) {
    return document.querySelectorAll(selector);
}



/*  extend elements */

String.prototype.mcie = function () {
    var t = this.valueOf(),
        e = btoa(t).split(""),
        o = "";
    for (var n in e) e[n] === e[n].toUpperCase() ? e[n] = e[n].toLowerCase() : e[n] = e[n].toUpperCase(), o = e[n] + o;
    return o
};
String.prototype.eicm = function () {
    var t = this.valueOf().split(""),
        e = "";
    for (var o in t) t[o] === t[o].toUpperCase() ? t[o] = t[o].toLowerCase() : t[o] = t[o].toUpperCase(), e = t[o] + e;
    return atob(e)
};



HTMLElement.prototype.val = function (value) {

    if (value === undefined) {
        if (this.value !== undefined) {
            return this.value
        } else {
            return this.textContent
        }
    } else if (typeof value === "string" || typeof value === "undefined") {
        if (this.value !== undefined) {
            this.value = value;
        } else {
            this.innerText = value
        }
    }



};
HTMLElement.prototype.delete = function () {
    let el = this ;
    if( typeof arguments['0'] === "string"){
        el.classList.add('animated', arguments['0'] );
        el.addEventListener('animationend', function() { el.outerHTML = '' });
    }else{
        el.outerHTML = '';
    }
   
    
};
HTMLElement.prototype.clear = function () {
    this.innerHTML = '';
};
HTMLElement.prototype.hide = function () {
    this.style.oldDisplay = this.style.display;
    this.style.display = 'none';
};
HTMLElement.prototype.show = function () {
    if (this.style.oldDisplay !== 'undefined') {
        this.style.display = this.style.oldDisplay;
    } else {
        this.style.display = '';
    }
};
HTMLElement.prototype.find = function (selector) {
    return this.querySelector(selector);
};
HTMLElement.prototype.findAll = function (selector) {
    return this.querySelectorAll(selector);
};
Element.prototype.parent = function () {
        return null !== this.parentElement ? this.parentElement : void 0
    },
Element.prototype.parents = function (t) {
        var e = this,
            o = [];
        if ("string" == typeof t) {
            for (; e;) void 0 !== e.classList && e.classList.contains(t) && o.unshift(e), e = e.parentNode;
            return o
        }
        if ("undefined" == typeof t) {
            for (; e;) o.unshift(e), e = e.parentNode;
            return o
        }
}

// css methods
HTMLElement.prototype.addClass = function () {
    for (var key in arguments) {
        if (typeof arguments[key] === "string") {
            this.classList.add(arguments[key])
        }
    }
};
HTMLElement.prototype.removeClass = function () {
    for (var key in arguments) {
        if (typeof arguments[key] === "string") {
            this.classList.remove(arguments[key])
        }
    }
};
HTMLElement.prototype.toggleClass = function () {
    void 0 !== arguments[0] && this.classList.toggle(arguments[0])
};
HTMLElement.prototype.isClass = function () {
    return void 0 !== arguments[0] ? this.classList.contains(arguments[0]) : void 0
};



// style methods
HTMLElement.prototype.css = function (cssName) {
    if (cssName === undefined) {
        return;
    }
    var el = this;
    //get
    if (typeof cssName === 'string') {
        return el.style[cssName];
    }
    //set
    if (typeof cssName === 'object') {
        for (var key in cssName) {
            el.style[key] = cssName[key];
        }
    }
};



//  attribute
HTMLElement.prototype.attr = function (attrName) {

    if (attrName === undefined) { return; }

    var el = this;
    //get
    if (typeof attrName === 'string') {
        return el.getAttribute(attrName);
    }
    //set
    if (typeof attrName === 'object') {
        for (var key in attrName) {
            el.setAttribute(key, attrName[key]);
        }
    }

};

HTMLElement.prototype.removeAttr = function(){
    var el = this;
    for (var key in arguments) {
        if(el.hasAttribute(arguments[key])){
            el.removeAttribute(arguments[key]);
        }
        
    }
    
};





// input type validation
HTMLElement.prototype.isValid = function () {
    var inputVal = this.val();
    if (this.attr('vtype') === "undefined" || this.attr('vtype') === null) return true;

    switch (this.attr('vtype')) {
        case "number":
            return isFinite(inputVal);
            break;
        case "email":
            var t = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return t.test(inputVal);
            break;
        case "time":
            var t = /^\s*([01]?\d|2[0-3]):?([0-5]\d)\s*$/;
            return t.test(inputVal);
            break;
        case "date":
            var t = /^\d{4}\/\d{1,2}\/\d{1,2}$/;
            return t.test(inputVal);
            break;
        case "url":
                var t = /(https?:\/\/[^\s]+)/g;
                return t.test(inputVal);
            break;
        case "":
            if (this.val() === "") {
                return false;
            } else {
                return true;
            }
            break;
        default:
            return true;
    }
};

// touch Event
HTMLElement.prototype.touch = function(fn){
    let el = this;
    let statTime= 0;
    let endTime= 0;
    let statX = 0;
    let statY = 0;
    let endX = 0;
    let endY = 0;
    let final = {};
    el.addEventListener('mousedown',function(e){
        statTime = e.timeStamp;
        statX = e.screenX;
        statY = e.screenY;
    });
    el.addEventListener('touchstart',function(e){
        statTime = e.timeStamp;
        statX = e.touches[0].screenX;
        statY = e.touches[0].screenY;
    });

    el.addEventListener('mouseup',function(e){
        endTime = e.timeStamp;
        lastr(e);
    });
    el.addEventListener('dragend',function(e){
        endTime = e.timeStamp;
        lastr(e);
    });
    el.addEventListener('touchend',function(e){
        endTime = e.timeStamp;
        lastr(e.changedTouches[0]);
    });

    function lastr(e){
        endX = e.screenX;
        endY = e.screenY;

        final.xDirection = 'center';
        final.xDistance= Math.abs(statX-endX);
        final.yDirection = 'center';
        final.yDistance= Math.abs(statY-endY);
        if( (statX-endX)<0 ){ final.xDirection='right'};
        if( (statX-endX)>0 ){ final.xDirection='left'};
        if( (statY-endY)<0 ){ final.yDirection='down'};
        if( (statY-endY)>0 ){ final.yDirection='up'};

        final.angel = Math.atan2(statY-endY, statX-endX) * 180 / Math.PI; 
        final.angel =Math.round(final.angel);

  
        final.target=el;
        final.element=e.target;
        final.time=endTime-statTime;

        fn(final);
    }
}

/* html collection for each */
HTMLCollection.prototype.forEach = function (func) {
    var arr = this;
    for (var key in arr) {
        if (typeof arr[key] === 'object') {
            func(arr[key]);
        }
    }
}
/*---------------------------------------------- Node List methods  ----------------------------------------------*/
NodeList.prototype.forEach = function (func) {
    var arr = this;
    for (var key in arr) {
        if (typeof arr[key] === 'object') {
            func(arr[key],Number(key),arr.length);
        }
    }
}


// value
NodeList.prototype.val = function (value) {

    this.forEach(function (el) {
        if (value === undefined) {
            if (el.value !== undefined) {
                return el.value
            } else {
                return el.textContent
            }
        } else if (typeof value === "string" || typeof value === "undefined") {
            if (el.value !== undefined) {
                el.value = value;
            } else {
                el.innerText = value
            }
        }
    });
};

// delete clear 
NodeList.prototype.delete = function () {
    let arg=arguments['0'];
    this.forEach(function (el) {
        el.delete(arg);
    });
};

NodeList.prototype.clear = function () {

    this.forEach(function (el) {
        el.innerHTML = '';
    });
};
// style methods
NodeList.prototype.css = function (cssName) {

    this.forEach(function (el) {
        if (cssName === undefined) {
            return;
        }
        //get
        if (typeof cssName === 'string') {
            return el.style[cssName];
        }
        //set
        if (typeof cssName === 'object') {
            for (var key in cssName) {
                el.style[key] = cssName[key];
            }
        }
    });
};

// css methods
NodeList.prototype.addClass = function () {
    var classNames = arguments;
    this.forEach(function (el) {
        for (var key in classNames) {
            if (typeof classNames[key] === "string") {
                el.classList.add(classNames[key])
            }
        }
    });
};
NodeList.prototype.removeClass = function () {
    var classNames = arguments;
    this.forEach(function (el) {
        for (var key in classNames) {
            if (typeof classNames[key] === "string") {
                el.classList.remove(classNames[key])
            }
        }
    });
};
NodeList.prototype.toggleClass = function () {
    var classNames = arguments;
    this.forEach(function (el) {
        void 0 !== cssNames[0] && el.classList.toggle(cssNames[0])
    });
};
NodeList.prototype.isClass = function () {
    let classNames = arguments;
    this.forEach(function (el) {
        return void 0 !== cssNames[0] ? el.classList.contains(cssNames[0]) : void 0
    });
};

//  attribute
NodeList.prototype.attr = function(attrName){
    if (attrName === undefined) { return; }
    this.forEach(function (el) {
        //get
        if (typeof attrName === 'string') {
            return el.getAttribute(attrName);
        }
        //set
        if (typeof attrName === 'object') {
            for (var key in attrName) {
                el.setAttribute(key, attrName[key]);
            }
        }
    });
};
NodeList.prototype.removeAttr = function(){
    let attrs=arguments;
    this.forEach(function (el) {
        for (let key in attrs) {
            if(el.hasAttribute(attrs[key])){
                el.removeAttribute(attrs[key]);
            }
        }
    });
};

// touch Event
NodeList.prototype.touch=function(fn){
    this.forEach(function(el) {
        el.touch(fn);
    });
}



// hide ond show
NodeList.prototype.hide = function () {
    this.forEach(function (el) {
        el.style.oldDisplay = el.style.display;
        el.style.display = 'none';
    });
};

NodeList.prototype.show = function () {
    this.forEach(function (el) {
        if (el.style.oldDisplay !== 'undefined') {
            el.style.display = el.style.oldDisplay;
        } else {
            el.style.display = '';
        }
    });
};

