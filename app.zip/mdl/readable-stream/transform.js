module.exports = require('./readable').Transform
