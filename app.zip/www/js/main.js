const App = {
    "url":window.location.origin,
    "version":"1.0.5"

}

ajx.post({
    url:App.url,
    head:{
        reqtype:"getInfo"
    },
    progress:function(xhr){},
    callback:function(data,xhr){
      
        for(let key in data){
            App[key]=data[key]
        }
        window.document.title = "milamu - "+App.server_name

    }
});

var progress= function(xhr){

    var loader=id('ajaxLoader');
    var barUpload=qs('#ajaxLoader .upload-bar');
    var bardownload=qs('#ajaxLoader .download-bar');
   
    loader.style.display="flex";

    xhr.upload.onprogress=function(e){
        if (e.lengthComputable) {
            var percentComplete = Math.ceil((e.loaded / (e.total)) * 100);
            barUpload.style.width=percentComplete+"%";
        }
    }

    xhr.onloadstart = function (e) {
        
    };

    
    // listen for `error` event
    xhr.onerror = () => {
        console.error('Download failed.');
    }

    // listen for `abort` event
    xhr.onabort = () => {
        console.error('Download cancelled.');
    }

    // listen for `progress` event
    xhr.onprogress = (e) => {
        // event.loaded returns how many bytes are downloaded
        // event.total returns the total number of bytes
        // event.total is only available if server sends `Content-Length` header
        
        var total=xhr.getResponseHeader("Content-Length");
       // console.log(`Downloaded ${e.loaded} of ${total} bytes`);
        var percentComplete = Math.ceil((e.loaded / (total)) * 100);
        bardownload.style.width=percentComplete+"%";
        //Math.ceil(e.loaded/1000)+" of "+ Math.ceil(e.total/1000)+" KB";
        
    }

    // listen for `load` event // The transfer is completed.
    xhr.onload = () => {
        
    };


    // One can also detect all three load-ending conditions (abort, load, or error) using the loadend event:
    xhr.onloadend = function (e) {
        loader.style.display="none";
        barUpload.style.width="0%";
        bardownload.style.width="0%";
    };

    
}




var DBMU = {
    tools:{
        dateformatC:function(inputD,value){
            switch(inputD){
                case"dd-mm-yyyy":
                    return value.split("-").reverse().join("-");
                break;
                case"yyyy-mm-dd":
                    return value.split("-").reverse().join("-");
                break;
                case"dd-mm-yyyy hh-ii-ss":
                    var dt=value.split(" ")
                    var d= dt[0].split("-").reverse().join("-");
                    return d+" "+dt[1];
                break;
                case"yyyy-mm-dd hh:ii:ss":
                    var dt=value.split(" ");
                    var d= dt[0].split("-").reverse().join("-");
                    return d+" "+dt[1]
                break;
            }
        },
    },

    updateApp:function(btn){
        btn.find('i').addClass('a_spin');

        ajx.get({
            url:"https://raw.githubusercontent.com/masoudahmadvand/milamu/main/upconf.json",
            callback:function(data,xhr){
                data=JSON.parse(data);
                if(data.version==App.version){
                    btn.find('i').removeClass('a_spin');
                    alert("your app is update already");
                    return;
                }
                var confirmUpdate = confirm(data.msg);
                    if (confirmUpdate == true) {
                        ajx.get({
                            url:data.url,
                            responseType:"blob",
                            callback:function(data,xhr){
                                
                                ajx.post({
                                    url:App.url,
                                    head:{
                                        reqType:"updateApp"
                                    },
                                    file:data,
                                    callback:function(data,xhr){
                                        if(xhr.getResponseHeader("err")!="0"){
                                            alert(data);
                                            return;
                                        }
                                        alert("pleas close and start again the milamu server")
                                    }
                                })
                                
                            }
                        });
                    } else {
                        btn.find('i').removeClass('a_spin');
                        
                    }
            }
        });
       
    },

    mysqlTypes:{
        tinyint:{
            type:'numeric',
            desc:''
        },
        smallint:{
            type:'numeric',
            desc:''
        },
        mediumint:{
            type:'numeric',
            desc:''
        },
        int:{
            type:'numeric',
            desc:''
        },
        bigint:{
            type:'numeric',
            desc:''
        },
        decimal:{
            type:'numeric',
            desc:''
        },
        float:{
            type:'numeric',
            desc:''
        },
        double:{
            type:'numeric',
            desc:''
        },
        real:{
            type:'numeric',
            desc:''
        },
        bit:{
            type:'numeric',
            desc:''
        },
        boolean:{
            type:'numeric',
            desc:''
        },
        serial:{
            type:'numeric',
            desc:''
        },
        date:{
            type:'date',
            desc:''
        },
        datetime:{
            type:'datetime',
            desc:''
        },
        timestamp:{
            type:'datetime',
            desc:''
        },
        time:{
            type:'time',
            desc:''
        },
        year:{
            type:'datetime',
            desc:''
        },
        char:{
            type:'string',
            desc:''
        },
        varchar:{
            type:'string',
            desc:''
        },
        tinytext:{
            type:'string',
            desc:''
        },
        text:{
            type:'string',
            desc:''
        },
        mediumtext:{
            type:'string',
            desc:''
        },
        longtext:{
            type:'string',
            desc:''
        },
        binary:{
            type:'string',
            desc:''
        },
        varbinary:{
            type:'string',
            desc:''
        },
        enum:{
            type:'select',
            desc:''
        },
        set:{
            type:'string',
            desc:''
        },
        tinyblob:{
            type:'file',
            desc:''
        },
        mediumblob:{
            type:'file',
            desc:''
        },
        blob:{
            type:'file',
            desc:''
        },
        longblob:{
            type:'file',
            desc:''
        },
        
    }
    ,

    
    showAddServer:function(){
        let addserverForm=id('dbuiAddServer').cloneNode(true);
        addserverForm.removeAttribute('id');
        internalwindow.create({
            title:'Add Server',
            content:addserverForm,
            taskbar:id('dbuiTaskbar'),
            onbeforeCreate:function(innwindow){
                innwindow.css({width:"250px",height:"330px",resize:"none"});
                innwindow.find('.internalwindow-container').css({overflow:"hidden"});
                innwindow.find('.maximize-internalwindow').css({display:"none"});
            },
            callback:function(innwindow){
                innwindow.find('[name="host"]').value=window.location.hostname;
            }
        });

    },
    addServer:function(btn){
        let form = btn.parents("dbui-addserver-container")[0];
        
        let host = form['host'].value ;
        let port = form['port'].value ;
        let username = form['username'].value ;
        let password = form['password'].value ;

        if(window.location.hostname===host){host="localhost";}
        ajx.post({
            url:App.url,
            head:{
                reqtype:"addServer"
            },
            params:{
                "host":host,
                "port":port,
                "user":username,
                "password":password,
                "execute":"SHOW VARIABLES LIKE '%version%';",
                "ip":form['host'].value
            },
            progress:function(xhr){
                progress(xhr)
            },
            callback:function(data,xhr){
                if(xhr.getResponseHeader("err")!="0"){
                    console.error(data);
                    alert(data);
                    return;
                }
                
                let information="";
                data.forEach(function(row){
                    information=information+row.Variable_name+" : "+row.Value+"\n";
                });

                let serverModel = id('dbuiServerModel').cloneNode(true);
                serverModel.removeAttribute('id');
                serverModel.find('[fill="servername"]').innerHTML=xhr.getResponseHeader("dataServer");
                serverModel.find('[fill="servername"]').title=information+"\nip : "+form['host'].value+"\nport : "+port;
                serverModel.params={"host":host,"port":port,"user":username,"password":password}
    
                id('dbuiServersList').appendChild(serverModel);
                btn.parents('internalwindow')[0].delete();
    
                serverModel.find(".dbui-server-title").click();
    
                form['username'].value="" ;
                form['password'].value="" ;
            }
        });


    },
    removeServer:function(btn){
        let server = btn.parents('dbui-server-model')[0];
        if (confirm("are you sure to close '"+server.params.host+"' on port "+server.params.port+"?")) {
            btn.parents('dbui-server-model')[0].delete();
           
          } 
    },
    showServerMenu:function(btn,ev){
        ev.preventDefault();
        qsa("[contextmenu]").css({display:"none"});
        let server = btn.parents('dbui-server-model')[0];
        let menu=server.find(".dbui-server-tools");
        menu.css({display:"block",top:ev.clientY+"px",left:ev.clientX+"px"})
        window.onclick=function(){
            menu.css({display:"none"});
            window.onclick=null
        };

        window.oncontextmenu=function(event){
            if(event.clientX < menu.offsetLeft || event.clientX > menu.offsetLeft+menu.clientWidth){
                menu.css({display:"none"});
            }else if(event.clientY < menu.offsetTop || event.clientY > menu.offsetTop+menu.clientHeight){
                menu.css({display:"none"});
            }
        };
        
    },



    // users
    openServerUsers:function(btn){
        let server = btn.parents('dbui-server-model')[0];
        let usersModel=id('dbmuUsersPanelModel').cloneNode(true);
        usersModel.removeAttribute('id');

        internalwindow.create({
            title: "users manager",
            content:usersModel,
            taskbar:id('dbuiTaskbar'),
            callback:function(innwindow){
                innwindow.params= {};
                for(var key in server.params){innwindow.params[key]=server.params[key]};
                innwindow.find('[btn="userList"]').click();
            }
        });

        
    },
    loadUsers:function(btn){
        let userpanel = btn.parents('internalwindow')[0];
        userpanel.findAll('.dbmu-users-conatiner').css({display:'none'});
        let usersListContainer = userpanel.find('.dbmu-users-list-conatiner');
        usersListContainer.clear();
        userpanel.params.execute="SELECT user,host FROM mysql.user";
        ajx.post({
            url:App.url,
            params:userpanel.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                if(xhr.getResponseHeader("err")!="0"){console.error(data);return;
                }
                data.forEach(function(userData){
                    let userModel=id('dbmuUserModel').cloneNode(true);
                    userModel.removeAttribute('id');
                    userModel.find('.dbmu-user-model-name').innerHTML="user : "+userData.user;
                        
                    let hostname =userData.host ; if(userData.host=="%"){hostname="any host"}
                    userModel.find('.dbmu-user-model-host').innerHTML="can access from<br>"+hostname;
                    userModel.userinfo=userData;
                    usersListContainer.appendChild(userModel);
                });
                usersListContainer.css({display:"block"});
            }
        });

    },
    openAddUserPanel:function(btn){
        let userpanel = btn.parents('internalwindow')[0];
        userpanel.findAll('.dbmu-users-conatiner').css({display:'none'});
        userpanel.find('.dbmu-add-user-conatiner').css({display:'block'});


        // fill databaseSelect element
        let databaseSelect=userpanel.find('[name="databaseSelect"]');
        userpanel.params.execute="show databases;"
        ajx.post({
            url:App.url,
            params:userpanel.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                databaseSelect.clear();
                let options='<option value="*" selcted>all databases</option>';
                data.forEach(function(row){
                    if(row.Database!="information_schema" && row.Database!="mysql" ){
                        options=options+'<option value="'+row.Database+'">'+row.Database+'</option>';
                    }
                });
                databaseSelect.innerHTML=options;

                // fill tableSelect element
                databaseSelect.onchange=function(){
                    let tableSelect=userpanel.find('[name="tableSelect"]');
                    tableSelect.clear();
                    if(databaseSelect.value=="*"){
                        tableSelect.innerHTML='<option value="*" selcted>all tables</option>';
                        userpanel.find('[name="FILE"]').removeAttribute('disabled');
                        userpanel.find('[name="SUPER"]').removeAttribute('disabled');
                        userpanel.find('[name="PROCESS"]').removeAttribute('disabled');
                        userpanel.find('[name="RELOAD"]').removeAttribute('disabled');
                        userpanel.find('[name="SHUTDOWN"]').removeAttribute('disabled');
                        userpanel.find('[name="SHOW DATABASES"]').removeAttribute('disabled');
                        userpanel.find('[name="REPLICATION CLIENT"]').removeAttribute('disabled');
                        userpanel.find('[name="REPLICATION SLAVE"]').removeAttribute('disabled');
                        userpanel.find('[name="CREATE USER"]').removeAttribute('disabled');
                        return;
                    }
                    userpanel.find('[name="FILE"]').setAttribute('disabled','true');
                    userpanel.find('[name="SUPER"]').setAttribute('disabled','true');
                    userpanel.find('[name="PROCESS"]').setAttribute('disabled','true');
                    userpanel.find('[name="RELOAD"]').setAttribute('disabled','true');
                    userpanel.find('[name="SHUTDOWN"]').setAttribute('disabled','true');
                    userpanel.find('[name="SHOW DATABASES"]').setAttribute('disabled','true');
                    userpanel.find('[name="REPLICATION CLIENT"]').setAttribute('disabled','true');
                    userpanel.find('[name="REPLICATION SLAVE"]').setAttribute('disabled','true');
                    userpanel.find('[name="CREATE USER"]').setAttribute('disabled','true');
                    
                    userpanel.params.database=databaseSelect.value;
                    userpanel.params.execute="show tables;"
                    ajx.post({
                        url:App.url,
                        params:userpanel.params,
                        progress:function(xhr){},
                        callback:function(data,xhr){
                            if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                            if(err!=null){ alert(err.message); return; }
                            let tableoptions='<option value="*" selcted>all tables</option>';
                            DBMU.json(tbdata).rows.forEach(function(trow){
                                let tablaname = trow["Tables_in_"+databaseSelect.value]
                                tableoptions=tableoptions+'<option value="'+tablaname+'">'+tablaname+'</option>';
                            });
                            tableSelect.innerHTML=tableoptions;
                        }
                    });
                    delete userpanel.params.database;
                }
            }
        });
        

    },
    addUserCheckPrivileges:function(btn){
        let fields=btn.parents('dbmu-add-user-fieldset')[0].elements;
        fields.forEach(function(el){
            if(btn.checked && el.getAttribute('disabled')!=="true"){
                el.checked=true
            }else{
                el.checked=false
            }
        });
    },
    addUser:function(btn){
        let userpanel = btn.parents('internalwindow')[0];
        let form = btn.parents('dbmu-add-user-conatiner')[0];
        

        let username = form['login'].elements['username'];if(username.value==""){alert('requiere : user name');username.focus;return;}else{username=username.value;}
        let host = form['login'].elements['hostname'];if(host.value==""){host="%"}
        let password = form['login'].elements['password'];if(password.value==""){alert('requiere : password');password.focus;return;}else{password=password.value;}
        let repassword = form['login'].elements['repassword'];if(repassword.value!=password){alert('requiere : password not match');repassword.focus;return;}

        let database=form['database'].elements['databaseSelect'].value;
        let table=form['database'].elements['tableSelect'].value;
        if(database != "*"){database="`"+database+"`"};
        if(table != "*"){table="`"+table+"`"};
        
        let privilege ="";
        form['data'].elements.forEach(function(el){
            if(el.name !=""){
                if(el.checked){
                    privilege=privilege+el.name+", "
                }
            };
        });
        form['structure'].elements.forEach(function(el){
            if(el.name !=""){
                if(el.checked){
                    privilege=privilege+el.name+", "
                }
            };
        });
        form['admin'].elements.forEach(function(el){
            if(el.name !=""){
                if(el.checked){
                    privilege=privilege+el.name+", "
                }
            };
        });
        privilege=privilege.slice(0, -2);

       
            



        
        userpanel.params.execute="CREATE USER `"+username+"`@`"+host+"` IDENTIFIED BY '"+password+"';";
        //console.dir(userpanel.params.execute);
        //'CREATE USER `'+username'+`@`'+host+'` IDENTIFIED BY `'+password+'`';
        ajx.post({
            url:App.url,
            params:userpanel.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                userpanel.params.execute='GRANT '+privilege+' ON  '+database+'.'+table+' TO `'+username+'`@`'+host+'`;';
                ajx.post({
                    url:App.url,
                    params:userpanel.params,
                    progress:function(xhr){},
                    callback:function(data,xhr){
                        if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                        form.reset();
                        form.find('[name="FILE"]').removeAttribute('disabled');
                        form.find('[name="SUPER"]').removeAttribute('disabled');
                        form.find('[name="PROCESS"]').removeAttribute('disabled');
                        form.find('[name="RELOAD"]').removeAttribute('disabled');
                        form.find('[name="SHUTDOWN"]').removeAttribute('disabled');
                        form.find('[name="SHOW DATABASES"]').removeAttribute('disabled');
                        form.find('[name="REPLICATION CLIENT"]').removeAttribute('disabled');
                        form.find('[name="REPLICATION SLAVE"]').removeAttribute('disabled');
                        form.find('[name="CREATE USER"]').removeAttribute('disabled');
                        userpanel.find('[btn="userList"]').click();
                    }
                });
            }
        });

        return;
        



        //GRANT SELECT, INSERT, UPDATE, DELETE ON `contacts`.`*` TO `smithj`@`localhost`;
    },
    deleteUser:function(btn){
        let userpanel = btn.parents('internalwindow')[0];
        let userModel = btn.parents('dbmu-user-model')[0];
        let userinfo=userModel.userinfo;

        userpanel.params.execute="DROP USER `"+userinfo.user+"`@`"+userinfo.host+"`;";
        //DROP USER 'smithj'@'localhost';
        if (confirm("are you sure to delete "+userinfo.user+"`@`"+userinfo.host+"` !?" )){
            ajx.post({
                url:App.url,
                params:userpanel.params,
                progress:function(xhr){},
                callback:function(data,xhr){
                    if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                    userModel.delete();
                }
            });
        }
        
    },
    editUser:function(btn){
        let userpanel = btn.parents('internalwindow')[0];
        let userModel = btn.parents('dbmu-user-model')[0];
        let userinfo=userModel.userinfo;
        userpanel.params.execute="SHOW GRANTS FOR `"+userinfo.user+"`@`"+userinfo.host+"`;"; 
        
        //userpanel.params.execute="select PRIVILEGE_TYPE from information_schema.USER_PRIVILEGES where GRANTEE=\"'"+userinfo.user+"'@'"+userinfo.host+"'\";";
        ajx.post({
            url:App.url,
            params:userpanel.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                console.log(DBMU.json(data))
            }
        });
        
    },
    changePassUser:function(btn){
        let userpanel = btn.parents('internalwindow')[0];
        let userModel = btn.parents('dbmu-user-model')[0];
        let userinfo=userModel.userinfo;
        userpanel.params.execute="SHOW GRANTS FOR `"+userinfo.user+"`@`"+userinfo.host+"`;";
        let oldpassword = prompt("enter the old password :", "");
        if(oldpassword===null){return;}

        ajx.post({
            url:App.url,
            params:{"host":userpanel.params.host,"port":userpanel.params.port,"user":userinfo.user,"password":oldpassword,"execute":"show databases"},
            progress:function(xhr){},
            callback:function(data,xhr){
                if(xhr.getResponseHeader("err")!="0"){ alert("wrong password");console.error(data);return;}
                let newpassword = prompt("enter the new password :", "");
                if(newpassword==null ){ return; }
                if(newpassword=="" ){ alert("password can not be empty"); return; }
                let renewpassword = prompt("enter the new password again :", "");
                if(renewpassword==null ){ return; }
                
                if(renewpassword===newpassword){
                    //"SET PASSWORD FOR `"+userinfo.user+"`@`"+userinfo.host+"` = PASSWORD('"+newpassword+"') ;";
                    userpanel.params.execute="UPDATE mysql.user SET Password=PASSWORD('"+newpassword+"') WHERE USER='"+userinfo.user+"' AND Host='"+userinfo.host+"';"
                    ajx.post({
                        url:App.url,
                        params:userpanel.params,
                        progress:function(xhr){},
                        callback:function(data,xhr){
                            if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                            alert("success.\nnew password is set. ");                        }
                    });
                }else{
                    alert("new password in not match");
                }
                
            }
        });
        
    },
    renameUser:function(btn){
        let userpanel = btn.parents('internalwindow')[0];
        let userModel = btn.parents('dbmu-user-model')[0];
        let userinfo=userModel.userinfo;
        let newanme = prompt("rename the name :", userinfo.user);
        if(newanme===null || newanme==="" || newanme===userinfo.user ){return;}
        userpanel.params.execute="RENAME USER '"+userinfo.user+"'@'"+userinfo.host+"' TO '"+newanme+"'@'"+userinfo.host+"';"
        ajx.post({
            url:App.url,
            params:userpanel.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                userinfo.user=newanme;
                userModel.find(".dbmu-user-model-name").innerHTML="user : "+userinfo.user;                      }
        });
        
    },


    // databases
    showDatabaseMenu:function(btn,ev){
        ev.preventDefault();
        qsa("[contextmenu]").css({display:"none"});
        let database = btn.parents('dbui-database-model')[0];
        let menu=database.find(".dbui-database-tools");
        menu.css({display:"block",top:ev.clientY+"px",left:ev.clientX+"px"})
        window.onclick=function(){
            menu.css({display:"none"});
            window.onclick=null
        };

        window.oncontextmenu=function(event){
            if(event.clientX < menu.offsetLeft || event.clientX > menu.offsetLeft+menu.clientWidth){
                menu.css({display:"none"});
            }else if(event.clientY < menu.offsetTop || event.clientY > menu.offsetTop+menu.clientHeight){
                menu.css({display:"none"});
            }
        };
        
    },
    addDatabase:function(btn){

        let databaseName = prompt("Database name :", "");
        if (databaseName == null || databaseName == "") { return; }
        let server = btn.parents('dbui-server-model')[0];
        server.params.execute="CREATE DATABASE `"+databaseName+"` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;";
        ajx.post({
            url:App.url,
            params:server.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}

                let dbModel=id('dbuiDatabaseModel').cloneNode(true);
                dbModel.removeAttribute('id');
                dbModel.find('[fill="databasename"]').innerHTML=databaseName;
                dbModel.params={}
                for(var key in server.params){dbModel.params[key]=server.params[key]};
                dbModel.params.database=databaseName;
                server.find('.dbui-database-list').appendChild(dbModel);
                server.find('.dbui-database-list').show();
            }
        });

    },
    loadDatabases:function(btn){
        if(btn.openmode==undefined){ btn.openmode=false }
        let server = btn.parents('dbui-server-model')[0];
        if(btn.openmode){server.find('.dbui-database-list').hide();btn.openmode=false;return;}
        server.params.execute="show databases;"

        ajx.post({
            url:App.url,
            params:server.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                if(xhr.getResponseHeader("err")!="0"){
                    console.error(data);
                    return;
                }
                server.find('.dbui-database-list').clear();
                data.forEach(function(row){
                    if(row.Database!="information_schema" && row.Database!="mysql" ){
                        let dbModel=id('dbuiDatabaseModel').cloneNode(true);
                        dbModel.removeAttribute('id');
                        dbModel.find('[fill="databasename"]').innerHTML=row.Database;
                        dbModel.find('[fill="databasename"]').title=row.Database;
                        dbModel.params={}
                        for(var key in server.params){dbModel.params[key]=server.params[key]};
                        dbModel.params.database=row.Database;
                        server.find('.dbui-database-list').appendChild(dbModel);
                    }
                    
                    
                });
                server.find('.dbui-database-list').show();
                btn.openmode=true;
            }
        });
    },
    backupDatabase:function(btn){
        let db = btn.parents('dbui-database-model')[0];

        // set backup name
        var d = new Date();
        d = d.toLocaleString().replace(/[/, :]/g,"-");
        var bkname=db.params.database+"("+d+").sql";
        
        
        db.params.execute="";
        db.find('.dbui-database-title i').addClass('a_spin');
        ajx.post({
            url:App.url,
            head:{
                reqtype:"takeBackup"
            },
            params:db.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                delete db.params.takebk;
                db.find('.dbui-database-title i').removeClass('a_spin');
                if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}

                
                var blob = new Blob([data], {type: "application/sql"});
                var url  = URL.createObjectURL(blob);

                var a = document.createElement('a');
                a.download=bkname;
                a.href=url;
                a.click();

            }
        });

        
     
    },
    backupDatabaseSchema:function(btn){
        let db = btn.parents('dbui-database-model')[0];

        // set backup name
        var d = new Date();
        d = d.toLocaleString().replace(/[/, :]/g,"-");
        var bkname=db.params.database+"-Schema ("+d+").sql";
        
        
        db.params.execute="";
        db.find('.dbui-database-title i').addClass('a_spin');
        ajx.post({
            url:App.url,
            head:{
                reqtype:"takeSchema"
            },
            params:db.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                delete db.params.takebk;
                db.find('.dbui-database-title i').removeClass('a_spin');
                if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}

                
                var blob = new Blob([data], {type: "application/sql"});
                var url  = URL.createObjectURL(blob);

                var a = document.createElement('a');
                a.download=bkname;
                a.href=url;
                a.click();

            }
        });

        
     
    },
    deleteDatabase:function(btn){ 
        let database = btn.parents('dbui-database-model')[0];
        if (confirm("are you sure to delete '"+database.params.database+"' database !? \nall data on the database will be delete")) {
            database.params.execute="DROP DATABASE `"+database.params.database+"`";
            
            ajx.post({
                url:App.url,
                params:database.params,
                progress:function(xhr){},
                callback:function(data,xhr){
                    if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                    database.delete();
                }
            });
           
        }
    },
    importTable:function(btn){
        let database = btn.parents('dbui-database-model')[0];
        id('loadfile').value="";
        id('loadfile').click();
        id('loadfile').onchange=function(e){
            var fr=new FileReader(); 
            fr.onload=function(){ 
                database.params.execute="";
                database.params.sqlfile=fr.result;
                database.find('.dbui-database-title i').addClass('a_spin');
                ajx.post({
                    url:App.url,
                    head:{
                        reqtype:"importBackup"
                    },
                    params:database.params,
                    progress:function(xhr){},
                    callback:function(data,xhr){
                        delete database.params.sqlfile;
                        database.find('.dbui-database-title i').removeClass('a_spin');
                        if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}

                        database.find('.dbui-database-title').openmode=false;
                        database.find('.dbui-database-title').click();

                    }
                });
            } 
              
            fr.readAsText(this.files[0]);


        }

    },
    

    // tables
    addTable:function(btn){

        let tableName = prompt("Table name:", "");
        if (tableName == null || tableName == "") { return; }
        let database = btn.parents('dbui-database-model')[0];
        database.params.execute='CREATE TABLE  `'+tableName+'` (`unique__id` int NOT NULL AUTO_INCREMENT, CONSTRAINT `'+tableName+'_pk` PRIMARY KEY (`unique__id`)) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;'
        ajx.post({
            url:App.url,
            params:database.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                let tbModel=id('dbuiTableModel').cloneNode(true);
                tbModel.removeAttribute('id');
                tbModel.find('[fill="tablename"]').innerHTML=tableName;
                tbModel.params= {};
                for(var key in database.params){tbModel.params[key]=database.params[key]};
                tbModel.table=tableName;
                tbModel.title=tableName;
                database.find('.dbui-tables-list').appendChild(tbModel);
                database.find('.dbui-tables-list').show();
            }
        });
        
    },
    loadTables:function(btn){
        if(btn.openmode==undefined){ btn.openmode=false }
        let database = btn.parents('dbui-database-model')[0];
        if(btn.openmode){database.find('.dbui-tables-list').hide();database.find('.fa-folder').removeClass("fa-folder-open"); btn.openmode=false;return;}
        database.find('.fa-folder').addClass("fa-folder-open");
        database.params.execute="show tables;"

        ajx.post({
            url:App.url,
            params:database.params,
            progress:function(xhr){

            },
            callback:function(data,xhr){
                if(xhr.getResponseHeader("err")!="0"){
                    console.error(data);
                    return;
                }
                
                database.find('.dbui-tables-list').clear();
                data.forEach(function(row){
                    let tbModel=id('dbuiTableModel').cloneNode(true);
                    tbModel.removeAttribute('id');
                    tbModel.find('[fill="tablename"]').innerHTML=row["Tables_in_"+database.params.database];
                    tbModel.params={};
                    for(var key in database.params){tbModel.params[key]=database.params[key]};
                    tbModel.table=row["Tables_in_"+database.params.database];
                    tbModel.title=row["Tables_in_"+database.params.database];
                    database.find('.dbui-tables-list').appendChild(tbModel);
                });
                database.find('.dbui-tables-list').show();
                btn.openmode=true;
            }
        });
        
    },
    renameTable:function(btn){
        let tableModel = btn.parents("dbui-table-model")[0];
        let newTbName = prompt("change the table name:", tableModel.table);
        if (newTbName == null || newTbName == "" || tableModel.table==newTbName) { tableModel.table=newTbName; return; }
        tableModel.params.execute='RENAME TABLE `'+tableModel.table+'` TO `'+newTbName+'`';

        ajx.post({
            url:App.url,
            params:tableModel.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                tableModel.table=newTbName;
                tableModel.find('[fill="tablename"]').innerHTML=newTbName;
            }
        });

    },
    backupTable:function(btn){
        var tb = btn.parents('dbui-table-model')[0];
        var d = new Date();
        d = d.toLocaleString().replace(/[/, :]/g,"-");
        var bkname=tb.table+"("+d+").sql";
        
        //tb.table
        tb.params.execute="";
        tb.params.table=tb.table;
        tb.find('.dbui-table-title i').addClass('a_spin');
        ajx.post({
            url:App.url,
            head:{
                reqtype:"takeBackup"
            },
            params:tb.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                delete tb.params.takebk;
                delete tb.params.table;
                tb.find('.dbui-table-title i').removeClass('a_spin');
                if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}

                var blob = new Blob([data], {type: "application/sql"});
                var url  = URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.download=bkname;
                a.href=url;
                a.click();

            }
        });



    },
    backupTableSchema:function(btn){
        var tb = btn.parents('dbui-table-model')[0];
        var d = new Date();
        d = d.toLocaleString().replace(/[/, :]/g,"-");
        var bkname=tb.table+"-Schema ("+d+").sql";
        
        //tb.table
        tb.params.execute="";
        tb.params.table=tb.table;
        tb.find('.dbui-table-title i').addClass('a_spin');
        ajx.post({
            url:App.url,
            head:{
                reqtype:"takeSchema"
            },
            params:tb.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                delete tb.params.takebk;
                delete tb.params.table;
                tb.find('.dbui-table-title i').removeClass('a_spin');
                if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}

                var blob = new Blob([data], {type: "application/sql"});
                var url  = URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.download=bkname;
                a.href=url;
                a.click();

            }
        });



    },
    deleteTable:function(btn){
        let tableModel = btn.parents('dbui-table-model')[0];
        if (confirm("are you sure to delete '"+tableModel.table+"' table!? \nall data on the table will be delete")) {
            tableModel.params.execute="DROP TABLE `"+tableModel.table+"`";
            ajx.post({
                url:App.url,
                params:tableModel.params,
                progress:function(xhr){},
                callback:function(data,xhr){
                    if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                    tableModel.delete();
                }
            });
        }
    },
    showTableMenu:function(btn,ev){
        ev.preventDefault();
        qsa("[contextmenu]").css({display:"none"});
        let table = btn.parents('dbui-table-model')[0];
        let menu=table.find(".dbui-table-tools");
        menu.css({display:"block",top:ev.clientY+"px",left:ev.clientX+"px"})
        window.onclick=function(){
            menu.css({display:"none"});
            window.onclick=null
        };

        window.oncontextmenu=function(event){
            if(event.clientX < menu.offsetLeft || event.clientX > menu.offsetLeft+menu.clientWidth){
                menu.css({display:"none"});
            }else if(event.clientY < menu.offsetTop || event.clientY > menu.offsetTop+menu.clientHeight){
                menu.css({display:"none"});
            }
        };
        
    },

    // table
    openTable:function(btn){
        let tableModel = btn.parents('dbui-table-model')[0];
        
        //MySql.database=tb.attr("name").replace(/Tables_in_/gi,"");
        let tableView =id('dbmuTableView').cloneNode(true);
        tableView.removeAttribute('id');

        internalwindow.create({
            title: tableModel.params.database +' / '+tableModel.table,
            content:tableView,
            taskbar:id('dbuiTaskbar'),
            onbeforeCreate:function(innwindow){
                innwindow.style.top= innwindow.offsetTop+(Math.random() * (30 - -30) + -30)+"px";
                innwindow.style.left= innwindow.offsetLeft+(Math.random() * (30 - -30)+ -30)+"px";
            },
            callback:function(innwindow){
                
                innwindow.dbconfig={
                    'table': tableModel.table,
                    'pageStart':0,
                    'pagesize': Number(innwindow.find('.dbmu-table-view-pager-pageSize').value) ,
                    'allrows':null,
                    'pages':null,
                    'sort':"",
                    'sortField':"",
                }
                innwindow.dbconfig["params"]={}
                for(var key in tableModel.params){innwindow.dbconfig.params[key]=tableModel.params[key]};
                
                
                DBMU.loadTableColumns(innwindow);
            }
        });
        
    
    },
    //load columns
    loadTableColumns:function(innwindow){
        let tableName = innwindow.dbconfig.table;
        let windowContainer = innwindow.find('.dbmu-table-view-content');
        windowContainer.innerHTML="<table><thead><tr></tr></thead><tbody></tbody></table>";


        // get columns
        innwindow.dbconfig.params.execute="SHOW FULL COLUMNS FROM `"+tableName+"`";

        ajx.post({
            url:App.url,
            params:innwindow.dbconfig.params,
            progress:function(xhr){

            },
            callback:function(columns,xhr){
                if(xhr.getResponseHeader("err")!="0"){
                    console.error(data);
                    return;
                }
                
                let tableHead=windowContainer.find('table thead tr');
                // set column name to table head
                tableHead.insertAdjacentHTML("afterbegin", "<th field='row_ln_num' onclick='DBMU.openSearchInTable(this)'><i class='fas fa-search'></i></th>");
                columns.forEach(function(column,index){
                    
                    let columnDom=document.createElement("th");

                    if(column.Field=="unique__id"){columnDom.style.display='none'};
            
                    columnDom.setAttribute("field",column.Field);
                    let sortClassASC="";
                    let sortClassDESC="";
                    if(innwindow.dbconfig.sortField==column.Field && innwindow.dbconfig.sort=="ASC"){ sortClassASC="active"; }
                    if(innwindow.dbconfig.sortField==column.Field && innwindow.dbconfig.sort=="DESC"){ sortClassDESC="active"; }
                    columnDom.insertAdjacentHTML("afterbegin",'<div class="dbui-table-column"><div class="dbui-column-tools"><i class="fas fa-cog" onclick="DBMU.openeditEasyColumn(this)"></i><i class="fas fa-sort-amount-up-alt sortColumns '+sortClassASC+'" onclick="DBMU.sortRows(this,`ASC`)"></i><i class="fas fa-sort-amount-up sortColumns '+sortClassDESC+'"  onclick="DBMU.sortRows(this,`DESC`)"></i><i class="far fa-arrows-alt moveColumn"></i></div><div class="dbui-column-name" title="'+column.Comment+'">'+column.Field+'</div></div>');
                    
                    tableHead.insertAdjacentElement("beforeend",columnDom);
                    
                    column.columntype=column.Type.match(/[^()]+/g).shift();
                    column.columnValue=column.Type.match(/\((.*)\)/);
                    if(column.Type.match(/\((.*)\)/) !=null){
                        column.columnValue=column.Type.match(/\((.*)\)/).pop()
                    }else{
                        column.columnValue=null
                    }
                    column.columnHtmlType=DBMU.mysqlTypes[column.columntype].type;
                    if(column.columntype=="tinyint"){column.columntype="boolean"}
                    columnDom.column=column;
                    
                    columnDom.findAll("*").forEach(function(el){el.columnDom=columnDom});
                    
                    
                });
                // set add column to table head
                let columnDomAdd=document.createElement("th");
                columnDomAdd.innerHTML='<div class="dbui-columns-tool" onclick="DBMU.addColumn(this)"><i class="fal fa-plus"></i>Column</div>';
                tableHead.insertAdjacentElement("beforeend",columnDomAdd);

                // changing column position
                new Sortable(tableHead, {
                    handle: '.moveColumn', // handle's class
                    animation: 150,
                    // Called when dragging element changes position
                    onSort: function(/**Event*/evt) {
                    let innwindow = evt.item.parents('internalwindow')[0];
                    let table = innwindow.dbconfig.table;
                    var columnDom=evt.item;
                    var column=columnDom.column;

                    let sqlString = "ALTER TABLE `"+table+"` CHANGE `"+column.Field+"` `"+column.Field+"` "+column.Type;
                    if(column.Collation!=null){
                        sqlString = sqlString +" CHARACTER SET utf8 COLLATE utf8_general_ci "
                    }
                    if(column.Default!=null){
                        sqlString = sqlString +" DEFAULT '"+column.Default+"'";
                    }
                    if(column.Comment!=""){
                        sqlString = sqlString +" COMMENT '"+column.Comment+"'";
                    }

                        // console.log(columnDom.previousElementSibling);
                    let prvDom = columnDom.previousElementSibling;
                    // first position
                    if(prvDom==null || prvDom.attr('field')=="row_ln_num"){
                        sqlString += " FIRST";
                    }
                    // last position
                        if(prvDom!=null && prvDom.attr('field')==null){
                        sqlString += " AFTER `"+prvDom.previousElementSibling.attr('field')+"`";
                    }
                    // normal position
                        if(prvDom!=null && prvDom.attr('field')!=null  && prvDom.attr('field')!="row_ln_num"){
                        sqlString += " AFTER `"+prvDom.attr('field')+"`";
                    }

                    innwindow.dbconfig.params.execute=sqlString;
                    ajx.post({
                        url:App.url,
                        params:innwindow.dbconfig.params,
                        progress:function(xhr){},
                        callback:function(data,xhr){
                                if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                                DBMU.loadTableColumns(innwindow);
                            }
                        });
            
                    }
                });
                // load table data
                DBMU.loadTableData(innwindow);

            }
        });

        
    },
    //load data in table
    loadTableData:function(innwindow){
        let tableName = innwindow.dbconfig.table;

        innwindow.style.cursor="wait";

         //set serach text
         let searchText="";
         if(innwindow.dbconfig.searchText!= undefined && innwindow.dbconfig.searchText!=null){
             searchText=innwindow.dbconfig.searchText;
         }
 
         let pagesize = innwindow.dbconfig.pagesize;
         let pageStart = innwindow.dbconfig.pageStart;

        // count all records and set innwindow.dbconfig.allrows / innwindow.dbconfig.pages
        innwindow.dbconfig.params.execute="select COUNT(*) AS allrows from `"+tableName+"` "+searchText+" ;";
        ajx.post({
            url:App.url,
            params:innwindow.dbconfig.params,
            "progress":function(xhr){
               
            },
            callback:function(data,xhr){
                if(xhr.getResponseHeader("err")!="0"){ console.error(data); return; }
                let allrows=Number(data[0].allrows);
                innwindow.dbconfig.allrows=allrows;
                innwindow.dbconfig.pages=Math.ceil(allrows/Number(innwindow.find('.dbmu-table-view-pager-pageSize').value));
                innwindow.find('.dbmu-table-view-pager-totalrownum').innerHTML=allrows;
            }
        });

       
            
        // put sort action
        let sortSql="";
        if(innwindow.dbconfig.sort!==""){
            sortSql="ORDER BY `"+innwindow.dbconfig.sortField+"` "+innwindow.dbconfig.sort;
        }


        // set command and exec it
        innwindow.dbconfig.params.execute="select `"+tableName+"`.* from `"+tableName+"` "+searchText+" "+sortSql+" LIMIT "+pageStart+","+pagesize;

        let pageNum=innwindow.find(".dbmu-table-view-pager-pageNumber").value-1;
        let pageSize=innwindow.find(".dbmu-table-view-pager-pageSize").value;
        let startNum=pageSize*pageNum;
        ajx.post({
            url:App.url,
            params:innwindow.dbconfig.params,
            progress:function(xhr){
                progress(xhr);
            },
            callback:function(rows,xhr){
                if(xhr.getResponseHeader("err")!="0"){ console.error(data); return; }
    
                let tableHead= innwindow.find('table thead');
                let tableBody= innwindow.find('table tbody');
                tableBody.innerHTML="";
                // set records to table body;


                rows.forEach(function(row,index){
                    let tableRow='<td tabindex=1 >'+(index+1+startNum)+'</td>'
                    for(let key in row){
                        
                        let cldate=tableHead.find('[field="'+key+'"]').column;
                        if(row[key]!=null){
                            switch(cldate.Type){
                                case"date":
                                    row[key]=DBMU.tools.dateformatC("yyyy-mm-dd",row[key])
                                break;
                                case"datetime":
                                    row[key]=DBMU.tools.dateformatC("yyyy-mm-dd hh:ii:ss",row[key])
                                break;
                            }
                        }
                        
                       
                        let nullCheck="";
                        if(row[key]==null){nullCheck=null;row[key]=""}
                        tableRow+='<td tabindex=1 c="'+key+'" onkeyup="DBMU.editTableRowByKey(this,event)" '+nullCheck+' ondblclick="DBMU.openEditorTableRow(this)"><pre class="value">'+row[key]+'</pre></td>';

                    }
                    // add row tools
                    tableRow+='<td><div class="dbmu-table-row-commands"><div class="dbmu-table-row-command"  onclick="DBMU.printTableRow(this)"><i class="fas fa-print"></i></div><div class="dbmu-table-row-command" onclick="DBMU.deleteTableRow(this)"><i class="fas fa-trash"></i></div></div></td>';
                    // put row in the table view
                    tableBody.insertAdjacentHTML("beforeend", "<tr class='row' >"+tableRow+"</tr>");
                });
    
                innwindow.style.cursor="default";
      
    
            }
        });
  


        

        
    },
    pagingTable:function(btn){
        let innwindow = btn.parents('internalwindow')[0];
        
        let pagesize=Number(innwindow.find('.dbmu-table-view-pager-pageSize').value) ;
        let pageNumber=Number(innwindow.find('.dbmu-table-view-pager-pageNumber').value) ;
        innwindow.dbconfig.pagesize=pagesize;
        innwindow.dbconfig.pages=Math.ceil(innwindow.dbconfig.allrows/pagesize);
        innwindow.find('.dbmu-table-view-pager-pageNumber').setAttribute('max',innwindow.dbconfig.pages);
        if( pageNumber > innwindow.dbconfig.pages){
            innwindow.find('.dbmu-table-view-pager-pageNumber').value=innwindow.dbconfig.pages;
        }

       
        innwindow.dbconfig.pageStart=(pagesize*pageNumber)-pagesize;
        if(innwindow.dbconfig.pageStart<0){innwindow.dbconfig.pageStart=0}

       
        DBMU.loadTableData(innwindow);
        
        
    },
    pagingTableBtn:function(btn,btnname){
        let innwindow = btn.parents('internalwindow')[0];
        let pageNumber=innwindow.find('.dbmu-table-view-pager-pageNumber') ;
        switch(btnname){
            case"fastBackward":
                pageNumber.value=1;
            break;
            case"stepBackward":
                if(pageNumber.value<=1){return;}
                pageNumber.value=Number(pageNumber.value)-1;
            break;
            case"stepForward":
                if(pageNumber.value>=innwindow.dbconfig.pages){return;}
                pageNumber.value=Number(pageNumber.value)+1;
            break;
            case"fastForward":
                pageNumber.value=innwindow.dbconfig.pages;
            break;
        }
        DBMU.pagingTable(btn);
    },
    printTableResult:function(btn){
        let innwindow = btn.parents('internalwindow')[0];
        let tableName = innwindow.dbconfig.table;
        //set serach text
        let searchText="";
        if(innwindow.dbconfig.searchText!= undefined && innwindow.dbconfig.searchText!=null){
            searchText=innwindow.dbconfig.searchText;
        }

        // put sort action
        let sortSql="";
        if(innwindow.dbconfig.sort!==""){
            sortSql="ORDER BY `"+innwindow.dbconfig.sortField+"` "+innwindow.dbconfig.sort;
        }

        //set command and exec it
        innwindow.dbconfig.params.execute="select `"+tableName+"`.* from `"+tableName+"` "+searchText+" "+sortSql;
        ajx.post({
            url:App.url,
            params:innwindow.dbconfig.params,
            progress:function(xhr){},
            callback:function(rows,xhr){
                if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}


                let printBody= id('print_frame');
                printBody.innerHTML="";
                let pageNum=innwindow.find(".dbmu-table-view-pager-pageNumber").value-1;
                let pageSize=innwindow.find(".dbmu-table-view-pager-pageSize").value;
                let startNum=pageSize*pageNum;
                // set records to print body;
                rows.forEach(function(row,index){
                    let printRow='<div class="print-table-row">'+'<div class="print-table-field"><b>'+(index+1+startNum)+'</b></div>'
                    for(let key in row){
                        if(key!="unique__id" ){
                            if(row[key]==null){row[key]=""}
                            printRow+='<div class="print-table-field"><h1>'+key+' :</h1><span>'+row[key]+'</span></div>';
                            
                        }
                    }
                    printRow+='</div>';
                    // put row in the table view
                    printBody.insertAdjacentHTML("beforeend", printRow);
                });

                id('DBUI').style.display="none";
                printBody.style.display="block";
                window.print();
                id('DBUI').style.display="flex";
                printBody.style.display="none";
            }
        });
    
    },

   
    addColumn:function(btn){
        let innwindow = btn.parents('internalwindow')[0];

        let newCulomn = prompt("insert column name:", "");
        if (newCulomn == null || newCulomn == "") { return; } 
        
        innwindow.dbconfig.params.execute='ALTER TABLE `'+innwindow.dbconfig.table+'` ADD `'+newCulomn+'` TEXT NULL  ';
        
        ajx.post({
            url:App.url,
            params:innwindow.dbconfig.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                DBMU.loadTableColumns(innwindow);
            }
        });
    },
    openEditColumn:function(btn){
        let columnDom=btn.columnDom;
        let form = columnDom.find('form');
        if(form!=undefined){ form.delete(); return }
        
        let column=columnDom.column;
       
        form = id('columnEditorModel').cloneNode(true);
        form.removeAttribute('id');
        


        form["name"].value=column.Field;
        form["type"].value=column.Type.match(/[^()]+/g).shift();
        if(column.Type.match(/[^()]+/g)!=null){ form["colength"].value=column.Type.match(/[^()]+/g).pop(); }else{ form["colength"].value=""; }
        if(column.Null=="YES"){ form["nullmode"].checked=true; }else{ form["nullmode"].checked=false; }
        if(column.Extra=="auto_increment"){ form["autoincrement"].checked=true; }else{ form["autoincrement"].checked=false; }
        form["character"].value=column.Collation;
        form["default"].value=column.Default;
        form["comment"].value=column.Comment;
        form["indexkey"].value=column.Key;

        let haslenght={ 'char':1, 'varchar':1, 'tinyint':1, 'smallint':1, 'mediumint':1, 'int':1, 'bigint':1, 'float':1, 'double':1, 'decimal':1, 'real':1,'enum':1 }
            if(haslenght[form['type'].value] !== undefined){
                form['colength'].parents('column-editor-property')[0].style.display="flex";
            }else{
                form['colength'].parents('column-editor-property')[0].style.display="none";
            }

     

        form.findAll("[btn]").forEach(function(el){
            el.columnDom=columnDom;
        });

        if(columnDom.previousElementSibling.getAttribute("field")==="unique__id"){
            form.find('[btn="moveleft"]').style.display="none";
        }
        if(columnDom.nextElementSibling.getAttribute("field")==undefined){
            form.find('[btn="moveRight"]').style.display="none";
        }

        columnDom.find('.dbui-table-column').appendChild(form);


    },
    editColumn:function(btn){

        let innwindow = btn.parents('internalwindow')[0];
        let columnDom=btn.columnDom;
        let column = columnDom.column;
        let form = columnDom.find('form').elements;
       


        let table = innwindow.dbconfig.table;
    

        let sqlString = "ALTER TABLE `"+table+"` CHANGE `"+column.Field+"` `"+form['name'].value+"` "+form['type'].value;

        let haslenght={ 'char':1, 'varchar':1, 'tinyint':1, 'smallint':1, 'mediumint':1, 'int':1, 'bigint':1, 'float':1, 'double':1, 'decimal':1, 'real':1,'enum':1 }
        if(haslenght[form['type'].value] !== undefined ){
            form['colength'].parents('column-editor-property')[0].style.display="flex";
            sqlString = sqlString+" ("+form['colength'].value+")";
            if(form['colength'].value==""){alert("put a lenght for "+form['type'].value);form['colength'].focus();  return;}
        }else{
            form['colength'].parents('column-editor-property')[0].style.display="none";
        }

        let hascharacterset={'char':1, 'varchar':1, 'tinytext':1, 'text':1, 'mediumtext':1, 'longtext':1, 'binary':1, 'varbinary':1,'enum':1 }
        if( hascharacterset[form['type'].value] !== undefined ){
            form['character'].parents('column-editor-property')[0].style.display="flex";
            if(form['character'].value!=""){
                sqlString = sqlString +" CHARACTER SET "+form['character'].value.split("_")[0]+" COLLATE "+form['character'].value
            }
        }else{
            form['character'].parents('column-editor-property')[0].style.display="none";
        }

        if(form['nullmode'].checked){ sqlString = sqlString +" NULL" }else{ sqlString = sqlString +" NOT NULL" }

        if(+form['default'].value !=""){
            if( hascharacterset[form['type'].value] !== undefined ){
                sqlString = sqlString +" DEFAULT '"+form['default'].value+"'";
            }else{
                sqlString = sqlString +" DEFAULT "+form['default'].value;
            }
        }
        


        if(form['autoincrement'].checked){ sqlString = sqlString +" AUTO_INCREMENT" }

        if(+form['comment'].value !=""){
            sqlString = sqlString +" COMMENT '"+form['comment'].value+"'";
        }

        innwindow.dbconfig.params.execute=sqlString;
        ajx.post({
            url:App.url,
            params:innwindow.dbconfig.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                DBMU.loadTableData(innwindow);
            }
        });

    },

    openeditEasyColumn:function(btn){
        let columnDom=btn.columnDom;
        let form = columnDom.find('form');
        if(form!=undefined){ form.delete(); return }
        
        let column=columnDom.column;
       
        form = id('columnEasyEditorModel').cloneNode(true);
        form.removeAttribute('id');
        


        form["name"].value=column.Field;
        form["type"].value=column.columntype;
 
      
        form["default"].value=column.Default;
        form["comment"].value=column.Comment;

       
        if(column.columntype =='enum'){
            form['colValues'].parents('column-editor-property')[0].style.display="block";
            let container=form.find('.column-editor-property-Values');
            column.columnValue.split(",").forEach(function(option){
                option=option.slice(1, -1)
                container.innerHTML=container.innerHTML+'<div><span>'+option+'</span><i class="fal fa-times" onclick="this.parent().delete()"></i></div>';
            });
            
        }else{
            form['colValues'].parents('column-editor-property')[0].style.display="none";
        }

     

        form.findAll("[btn]").forEach(function(el){
            el.columnDom=columnDom;
        });

     

        columnDom.find('.dbui-table-column').appendChild(form);

 
        new Sortable(form.find('.column-editor-property-Values'), {
           // handle: 'span', // handle's class
            animation: 150
        });


    },
    changeEditEasyColumn:function(btn){
        let type=btn.value;
        let form = btn.parents('column-editor-model')[0];
        switch(type){
            case"enum":
                form.find('[edit="values"]').style.display="block";
            break;
            default:
                form.find('[edit="values"]').style.display="none";
            break;
        }
    },
    changeColumnValues:function(el,e){
        if(e.keyCode!=13){return}
        
        let newValue=el.value;
        let container=el.parents('column-editor-property')[0].find('.column-editor-property-Values');
        container.innerHTML=container.innerHTML+'<div><span>'+newValue+'</span><i class="fal fa-times" onclick="this.parent().delete()"></i></div>';
        el.value="";
    },
    editEasyColumn:function(btn){

        let innwindow = btn.parents('internalwindow')[0];
        let columnDom=btn.columnDom;
        let column = columnDom.column;
        let form = columnDom.find('form').elements;
       


        let table = innwindow.dbconfig.table;
    

        let sqlString = "ALTER TABLE `"+table+"` CHANGE `"+column.Field+"` `"+form['name'].value+"` "+form['type'].value;


        switch(form['type'].value){
            case"enum":
                sqlString=sqlString+"("
                columnDom.findAll('.column-editor-property-Values span').forEach(function(el){
                    sqlString=sqlString+"'"+el.innerHTML+"',"
                })
                sqlString=sqlString.slice(0, -1);
                sqlString=sqlString+")";
            break;
        }


        let hascharacterset={'char':1, 'varchar':1, 'tinytext':1, 'text':1, 'mediumtext':1, 'longtext':1, 'binary':1, 'varbinary':1,'enum':1 }
        if( hascharacterset[form['type'].value] !== undefined ){
            sqlString = sqlString +" CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci "
        }


        if(form['default'].value !=""){
            if( hascharacterset[form['type'].value] !== undefined ){
                sqlString = sqlString +" DEFAULT '"+form['default'].value+"'";
            }else{
                sqlString = sqlString +" DEFAULT "+form['default'].value;
            }
        }

        if(form['comment'].value !=""){
            sqlString = sqlString +" COMMENT '"+form['comment'].value+"'";
        }
        

        innwindow.dbconfig.params.execute=sqlString;
        ajx.post({
            url:App.url,
            params:innwindow.dbconfig.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                if(xhr.getResponseHeader("err")!="0"){
                    console.error(data);
                    if(input.checked != undefined && input.checked==true){
                        input.checked=false
                    }else if(input.checked != undefined && input.checked==false){
                        input.checked=true
                    }
                    return; 
                }
                DBMU.loadTableColumns(innwindow);
            }
        });

    },
    deleteColumn:function(btn){
        let innwindow = btn.parents('internalwindow')[0];
        let columnDom=btn.columnDom;
        let column = columnDom.column;
        var r = confirm("are you sure you want delete '"+column.Field+"' !?");
        if (r == true) {

            let table = innwindow.dbconfig.table;
            innwindow.dbconfig.params.execute='ALTER TABLE `'+table+'` DROP COLUMN `'+column.Field+'`';
            ajx.post({
                url:App.url,
                params:innwindow.dbconfig.params,
                progress:function(xhr){},
                callback:function(data,xhr){
                    if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                    DBMU.loadTableColumns(innwindow);
                }
            });
            
        }
    },

    openaddTableRow:function(btn){
        let innwindow = btn.parents('internalwindow')[0];
        let insertPanel=innwindow.find('.dbmu-table-view-insert-container');
        let insertContainer=innwindow.find('[insertrowaria="fields"]');
        insertContainer.clear();
        if(insertPanel.style.display!="block"){
            insertPanel.style.display="block";
        }else{
            insertPanel.style.display="none";
            
            return;
        }
        
        
        innwindow.findAll('tr [field]').forEach(function(th){
            if(th.column!=undefined && th.column.Field!=="unique__id"){
               // console.log(th.column);
                let insertElement='';
                let insertElementClass="dbmu-table-view-insert-element";
                switch(th.column.columnHtmlType){
                    case"string":
                    insertElement='<div><span>'+th.column.Field+'</span><input class="'+insertElementClass+'" type="text" name="'+th.column.Field+'"  class=""></div>'
                    break;
                    case"numeric":
                    insertElement='<div><span>'+th.column.Field+'</span><input class="'+insertElementClass+'" type="number" name="'+th.column.Field+'"  class="" ></div>'
                    break;
                    case"date":
                    insertElement='<div><span>'+th.column.Field+'</span><input class="'+insertElementClass+'" type="date" name="'+th.column.Field+'" class="" pattern="\d{4}-\d{2}-\d{2}"></div>'
                    break;
                    case"datetime":
                    insertElement='<div><span>'+th.column.Field+'</span><input class="'+insertElementClass+'" type="datetime-local" name="'+th.column.Field+'" class="" pattern="\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}" step="1"></div>'
                    break;
                    case"time":
                    insertElement='<div><span>'+th.column.Field+'</span><input class="'+insertElementClass+'" type="time" name="'+th.column.Field+'"  class="" ></div>'
                    break;
                    case"file":
                    insertElement='<div><span>'+th.column.Field+'</span><input class="'+insertElementClass+'" type="text" name="'+th.column.Field+'"  class="" ></div>'; 
                    break;
                    case"select":
                        let options='<option value="" ></option>';
                        th.column.columnValue.split(",").forEach(function(opt){
                            let select="";
                            opt=opt.replace(/'/g,"");
                            options=options+'<option value="'+opt+'" '+select+'>'+opt+'</option>'
                        });
                        insertElement='<div><span>'+th.column.Field+'</span><select class="'+insertElementClass+'" name="'+th.column.Field+'" class="" value="">'+options+'</select></div>'
                    break;
                }
                insertContainer.innerHTML+=insertElement;

            }
            
        });
    },
    addTableRow:function(btn){
        let innwindow = btn.parents('internalwindow')[0];
        let insertPanel=innwindow.find('.dbmu-table-view-insert-container');
        let insertForm=innwindow.find('[insertrowaria="fields"]');
        let insertElements=innwindow.findAll('[insertrowaria="fields"] [name]');
        let table = innwindow.dbconfig.table;

        var fieldList="";
        var valueLis="";
        insertElements.forEach(function(el){
            var field= el.attr('name');
            let fval=null;
            switch(el.attr('type')){
                case"number":
                    fval=el.value;
                break;
                case"datetime-local":
                    fval="'"+el.value.replace("T"," ")+"'";
                break;
                default:
                    fval="'"+el.value+"'";
                break;

            }


            if(el.value !="" && el.value !=null){
                fieldList+='`'+field +'`,';
                valueLis+=fval+","
            }
            
        });
        fieldList=fieldList.slice(0, -1)
        valueLis=valueLis.slice(0, -1);
        
        innwindow.dbconfig.params.execute='INSERT INTO `'+table+'` ('+fieldList+') VALUES('+valueLis+') ;';
        ajx.post({
            url:App.url,
            params:innwindow.dbconfig.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                innwindow.find('[btn="lastpage"]').click();
                insertPanel.style.display="none";
            }
        });
    
    },
    clearaddTableRow:function(btn){
        let innwindow = btn.parents('internalwindow')[0];
        let insertForm=innwindow.find('[insertrowaria="fields"]');
        insertForm.reset();
    },
    closeaddTableRow:function(btn){
        let innwindow = btn.parents('internalwindow')[0];
        let insertPanel=innwindow.find('.dbmu-table-view-insert-container');
        let insertForm=innwindow.find('[insertrowaria="fields"]');
        insertForm.clear();
        insertPanel.style.display="none";
    },


    deleteTableRow:function(btn){

        btn.parents('row')[0].style.filter="brightness(0.8)";

        setTimeout(function() {
            var r = confirm("are you sure you want delete the row !?");
            btn.parents('row')[0].style.filter="";
            if(r!=true){return}
            let innwindow = btn.parents('internalwindow')[0];
            let table = innwindow.dbconfig.table;

            //set condition for delete
            let condition=""
            if(btn.parents('row')[0].find('[c="unique__id"]')==undefined){
                btn.parents('row')[0].findAll('[c]').forEach(function(el){
                    let elcolumn=el.parents('dbmu-table-view-content')[0].find('[field="'+el.getAttribute("c")+'"]').column;
                    var type = elcolumn.columnHtmlType;
                    var name = elcolumn.Field;
                    var value = el.find('.value').textContent.replace(/'/g,"\\'");;
    
                    if(type!=null && type!="file" ){
                        if(type!="numeric"){value="='"+value+"'"}else{value="="+value}
                        if(el.getAttribute("null")!=null){value=" IS NULL"}
                        condition=condition+"`"+name+"`"+value+" AND ";
    
                    }
                });
                condition=condition.substr(0,condition.length-5);
            }else{
                let uid=btn.parents('row')[0].find('[c="unique__id"] .value').innerHTML;
                condition+="unique__id="+uid;
            }
            
            
            
            let deleteCommand="DELETE FROM `"+table+"` WHERE "+condition;
            innwindow.dbconfig.params.execute=deleteCommand;
            ajx.post({
                url:App.url,
                params:innwindow.dbconfig.params,
                progress:function(xhr){},
                callback:function(data,xhr){
                    if(xhr.getResponseHeader("err")!="0"){console.error(data);return;}
                    DBMU.loadTableData(innwindow);
                }
            });
        }, 20);

        

    },
    printTableRow:function(btn){
        
        id("print_frame").innerHTML="";
        var printText=""
        btn.parents("row")[0].findAll('td').forEach(function(el){
            let columnName=el.getAttribute("c");
            if(columnName!=null && columnName!="unique__id"){
                    printText+='<div class="print-cell"><h1>'+columnName+' :</h1><span>'+el.innerHTML+'</span></div>'
            }
            
        });

        id('DBUI').style.display="none";
        id("print_frame").style.display="block";
        id("print_frame").innerHTML=printText;
        window.print();
        id('DBUI').style.display="flex";
        id("print_frame").style.display="none";
    },
    openEditorTableRow:function(field){

        let valueEl=field.find('.value');
        if(field.innerHTML!=valueEl.outerHTML){return;}
        valueEl.style.display="none";
        let oldval=valueEl.innerHTML;
        let column = field.parents('dbmu-table-view-content')[0].find('[field="'+field.getAttribute("c")+'"]').column;


        roweditor="";
        switch(column.columnHtmlType){
            case"string":
                roweditor='<textarea tabindex=1 sqType="textarea"  onblur="DBMU.editTableRow(this)" class="dbmu-table-view-row-editor">'+oldval+'</textarea>'
            break;
            case"numeric":
                roweditor='<input tabindex=1  type="number" sqType="number"  onblur="DBMU.editTableRow(this)" class="dbmu-table-view-row-editor" value="'+oldval+'">'
            break;
            case"date":
                roweditor='<input tabindex=1 type="text" sqType="date"  class="dbmu-table-view-row-editor" value="'+oldval+'" >'
                
            break;
            case"datetime":
                roweditor='<input tabindex=1 type="text" sqType="datetime-local" class="dbmu-table-view-row-editor" value="'+oldval.replace(" ","T")+'" pattern="\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}" step="1">'
            break;
            case"time":
                roweditor='<input tabindex=1 type="time" sqType="time" onblur="DBMU.editTableRow(this)" class="dbmu-table-view-row-editor" value="'+oldval+'">'
            break;
            case"file":
                roweditor='<input tabindex=1 type="file" sqType="file" onchange="DBMU.editTableRow(this)" onblur="DBMU.hideEditor(this)" class="dbmu-table-view-row-editor" value="">'; 
            break;
            case"select":
                let options='<option value="" ></option>';
                column.columnValue.split(",").forEach(function(opt){
                    let select="";
                    opt=opt.replace(/'/g,"")
                    if(oldval==opt){select="selected"}
                    options+='<option value="'+opt+'" '+select+'>'+opt+'</option>'
                });
                roweditor='<select tabindex=1 sqType="select" onblur="DBMU.editTableRow(this)" class="dbmu-table-view-row-editor" value="'+oldval+'">'+options+'</select>'
            break;
        }
        field.insertAdjacentHTML("beforeend",roweditor);
        switch(column.columnHtmlType){
            case"date":
            flatpickr(field.find('input'), {
                dateFormat: "d-m-Y",
                onClose:function(){
                        DBMU.editTableRow(field.find('input'))
                    }
                
            });
            break;
            case"datetime":
            flatpickr(field.find('input'), {
                enableTime: true,
                dateFormat: "d-m-Y H:i:S",
                onClose:function(){
                    DBMU.editTableRow(field.find('input'))
                }
            });
            break;
        }

        field.find('.dbmu-table-view-row-editor').onfocus = function(e){
            let el = e.target;
            if (typeof el.selectionStart == "number") {
                el.selectionStart = el.selectionEnd = el.value.length;
            }
        }
        field.find('.dbmu-table-view-row-editor').focus();
        
    },
    editTableRow:function(editor){
        let innwindow = editor.parents('internalwindow')[0];
        let field=editor.parent();
        let valueEl=field.find('.value');
        let oldval=valueEl.innerHTML;
        if(oldval==editor.value && editor.type!=="checkbox"){
            editor.delete();
            valueEl.style.display="block";
            return;
        }
        
        let column=field.parents('dbmu-table-view-content')[0].find('[field="'+field.getAttribute("c")+'"]').column
        
        let table = innwindow.dbconfig.table;

        let updatevalue="";
        editor.value=editor.value.replace(/'/g,"\\'");
        switch(editor.getAttribute("sqType")){
            case"textarea":
            updatevalue="'"+editor.value+"'";
            break;
            case"select-one":
            updatevalue="'"+editor.value+"'";
            break;
            case"number":
            updatevalue=editor.value;
            break;
            case"file":
                function bytesToSize(bytes) {
                    var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
                    if (bytes == 0) return '0 Byte';
                    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
                    return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
                }
  
            break;
            case"datetime-local":
                updatevalue="'"+DBMU.tools.dateformatC("dd-mm-yyyy hh-ii-ss",editor.value)+"'";
            break;
            case"date":
                updatevalue="'"+DBMU.tools.dateformatC("dd-mm-yyyy",editor.value)+"'";
            break;
            case"time":
            updatevalue="'"+editor.value+"'";
            break;
            default:
                updatevalue="'"+editor.value+"'";
            break
        }

        // set condition for update
        let condition="";
        if(editor.parents('row')[0].find('[c="unique__id"]')==undefined){
            editor.parents('row')[0].findAll('[c]').forEach(function(el){
                let elcolumn=el.parents('dbmu-table-view-content')[0].find('[field="'+el.getAttribute("c")+'"]').column;
                var type = elcolumn.columnHtmlType;
                var name = elcolumn.Field;
                var value = el.find('.value').textContent.replace(/'/g,"\\'");
                if(type!=null && type!="file" ){
                    if(type!="numeric"){value="='"+value+"'"}else{value="="+value}
                    if(el.getAttribute("null")!=null){value=" IS NULL"}
                    condition=condition+"`"+name+"`"+value+" AND ";
    
                }
            });
            condition=condition.substr(0,condition.length-5);
        }else{
            let uid=editor.parents('row')[0].find('[c="unique__id"] .value').innerHTML;
                condition+="unique__id="+uid;
        }
        
   
        innwindow.dbconfig.params.execute="UPDATE `"+table+"` SET `"+column.Field+"`="+updatevalue+" WHERE "+condition;
        ajx.post({
            url:App.url,
            params:innwindow.dbconfig.params,
            progress:function(xhr){},
            callback:function(data,xhr){
                valueEl.style.display="block";
                if(xhr.getResponseHeader("err")!="0"){ editor.delete();console.error(data);return;}
                editor.value=editor.value.replace(/\\'/g,"'");
                switch(editor.type){
                    case"datetime-local":
                    valueEl.innerHTML=editor.value.replace("T"," ");
                    break;
                    default:
                        valueEl.textContent=editor.value;
                    break;
                }
               
                editor.delete();
                field.removeAttribute('null');
            }
        });

    },
    editTableRowByKey:function(field,e){

      //  console.log(e)
        // 39 right , 37 left , 38 up , 40 down
        if(e.keyCode!==13  ){return}
        
        DBMU.openEditorTableRow(field)
      

    },
    hideEditor:function(editor){
        editor.style.display="none";
        editor.parent().find('.value').style.display="block";;
    },

    sortRows:function(btn,sort){
        let innwindow = btn.parents('internalwindow')[0];
        let field = btn.columnDom.column.Field
        
        if(btn.isClass("active")){
            innwindow.dbconfig.sort="";
            innwindow.findAll(".sortColumns").removeClass("active")
        }else{
            innwindow.findAll(".sortColumns").removeClass("active")
            innwindow.dbconfig.sort=sort;
            innwindow.dbconfig.sortField=field;
            btn.addClass("active")
        }

        DBMU.loadTableData(innwindow);
    },
    openSearchInTable:function(btn){
        let innwindow = btn.parents('internalwindow')[0];
        let searchPanel=innwindow.find('.dbmu-table-view-search-container');
        let searchContainer=innwindow.find('[searcharia="fields"]');
        if(searchPanel.style.display!="block"){
            searchPanel.style.display="block";
        }else{
            searchPanel.style.display="none";
            searchContainer.clear();
            return;
        }


        // set column list for selectbox
        var selectColumns= innwindow.find('.dbmu-table-view-search-colums');
        var selectColumnsHTML="";
        let firstColumn="";
        btn.parent().findAll('[field]').forEach(function(th){
            if(th.column!=undefined && th.column.Field!=="unique__id"){
                if(firstColumn==""){firstColumn=th.column}
                selectColumnsHTML+="<option value='"+th.column.Field+"' type="+th.column.columnHtmlType+">"+th.column.Field+"</option>" ;
            }
        });
        selectColumns.innerHTML=selectColumnsHTML;
        
        // set value type input for first column
        let valueContainer=innwindow.find('.dbmu-table-view-search-value');
        let classname="dbmu-table-view-search-value-elem";
        var valueElement="";
        switch(firstColumn.columnHtmlType){
            case"string":
                valueElement='<input type="text" class="'+classname+'">'
            break;
            case"numeric":
                valueElement='<input type="number" class="'+classname+'">'
            break;
            case"date":
                valueElement='<input type="date" pattern="\d{4}-\d{2}-\d{2}" class="'+classname+'">'
            break;
            case"datetime":
                valueElement='<input type="datetime-local" pattern="\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}" step="1" class="'+classname+'">'
            break;
            case"time":
                valueElement='<input type="time" class="'+classname+'">'
            break;
            case"file":
                valueElement='<input type="file" class="'+classname+'">'; 
            break;
            case"select":
                let options='';
                firstColumn.columnValue.split(",").forEach(function(opt){
                    opt=opt.replace(/'/g,"");
                    options=options+'<option value="'+opt+'" >'+opt+'</option>'
                });
                valueElement='<select class="'+classname+'">'+options+'</select>'
            break;
        }
        valueContainer.innerHTML=valueElement;
        
        

        // add element if in search is exist
        if(innwindow.dbconfig.search!=undefined){
            for(var key in innwindow.dbconfig.search){
                let row=innwindow.dbconfig.search[key]
                let column = btn.parent().find('[field="'+row.field+'"]').column;
                let value= row.val;
                let operatorval=row.operator;
                let searchElement=document.createElement("div");

                let conditionsOperatorsElement="<select  operator='"+column.Field+"' class='dbmu-table-view-search-conditionsOperators' value='"+operatorval+"'><option value='='>Equal</option><option value='>'>Greater than</option><option value='>='>Greater than or equal</option><option value='<'>Less than</option><option value='<='>Less than or equal</option><option value='!='>Not equal</option><option value='LIKE'>LIKE</option></select>";
                let deleteItem='<i class="fal fa-times" onclick="this.parent().delete()"></i>';
                let searchElementClass="dbmu-table-view-search-element";
                switch(column.columnHtmlType){
                    case"string":
                        searchElement.innerHTML=deleteItem+'<span>'+column.Field+'</span>'+conditionsOperatorsElement+'<input class="'+searchElementClass+'" type="text" name="'+column.Field+'"  class="" value="'+value+'">'
                    break;
                    case"numeric":
                        searchElement.innerHTML=deleteItem+'<span>'+column.Field+'</span>'+conditionsOperatorsElement+'<input class="'+searchElementClass+'" type="number" name="'+column.Field+'"  class="" value="'+value+'">'
                    break;
                    case"date":
                        searchElement.innerHTML=deleteItem+'<span>'+column.Field+'</span>'+conditionsOperatorsElement+'<input class="'+searchElementClass+'" type="date" name="'+column.Field+'" class="" value="'+value+'"  pattern="\d{4}-\d{2}-\d{2}">'
                    break;
                    case"datetime":
                        searchElement.innerHTML=deleteItem+'<span>'+column.Field+'</span>'+conditionsOperatorsElement+'<input class="'+searchElementClass+'" type="datetime-local" name="'+column.Field+'" class="'+value+'" value="" pattern="\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}" step="1">'
                    break;
                    case"time":
                        searchElement.innerHTML=deleteItem+'<span>'+column.Field+'</span>'+conditionsOperatorsElement+'<input class="'+searchElementClass+'" type="time" name="'+column.Field+'"  class="" value="'+value+'">'
                    break;
                    case"file":
                        searchElement.innerHTML=deleteItem+'<span>'+column.Field+'</span>'+conditionsOperatorsElement+'<input class="'+searchElementClass+'" type="text" name="'+column.Field+'"  class="" value="'+value+'">'; 
                    break;
                    case"select":
                        let options='<option value="" ></option>';
                        column.columnValue.split(",").forEach(function(opt){
                            let select="";
                           
                            if("'"+value+"'"==opt){
                                select="selected=true";
                            }else{
                                select="";
                            }
                            opt=opt.replace(/'/g,"");
                            options=options+'<option value="'+opt+'" '+select+'>'+opt+'</option>'
                        });
                        
                        searchElement.innerHTML=deleteItem+'<span>'+column.Field+'</span>'+conditionsOperatorsElement+'<select class="'+searchElementClass+'" name="'+column.Field+'" class="" value="'+value+'">'+options+'</select>'
                    break;
                }
                searchContainer.appendChild(searchElement);
                searchElement.find('[operator="'+column.Field+'"] [value="'+operatorval+'"]').setAttribute("selected","selected");
            }
        }
    
    },
    searchInTableChangeColumn:function(select){
        let innwindow = select.parents('internalwindow')[0];
        let valueContainer=innwindow.find('.dbmu-table-view-search-value');
        let column = innwindow.find('table thead tr [field="'+select.value+'"]').column;
        let classname="dbmu-table-view-search-value-elem";
        var valueElement="";
        switch(column.columnHtmlType){
            case"string":
                valueElement='<input type="text" class="'+classname+'">'
            break;
            case"numeric":
                valueElement='<input type="number" class="'+classname+'">'
            break;
            case"date":
                valueElement='<input type="date" pattern="\d{4}-\d{2}-\d{2}" class="'+classname+'">'
            break;
            case"datetime":
                valueElement='<input type="datetime-local" pattern="\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}" step="1" class="'+classname+'">'
            break;
            case"time":
                valueElement='<input type="time" class="'+classname+'">'
            break;
            case"file":
                valueElement='<input type="file" class="'+classname+'">'; 
            break;
            case"select":
                let options='';
                column.columnValue.split(",").forEach(function(opt){
                    opt=opt.replace(/'/g,"");
                    options=options+'<option value="'+opt+'" >'+opt+'</option>'
                });
                valueElement='<select class="'+classname+'">'+options+'</select>'
            break;
        }
        valueContainer.innerHTML=valueElement;

    },
    searchInTableAddCondition:function(btn){
        let innwindow = btn.parents('internalwindow')[0];
        let searchPanel=innwindow.find('.dbmu-table-view-search-container');
        let searchContainer=innwindow.find('[searcharia="fields"]');

        let fieldName=searchPanel.find('.dbmu-table-view-search-colums').value;
        let operatorval=searchPanel.find('.dbmu-table-view-search-conditaions').value;

   
        let conditionsOperatorsElement="<select  operator='"+fieldName+"' value='"+operatorval+"' class='dbmu-table-view-search-conditionsOperators' ><option value='='>Equal</option><option value='>'>Greater than</option><option value='>='>Greater than or equal</option><option value='<'>Less than</option><option value='<='>Less than or equal</option><option value='!='>Not equal</option><option value='LIKE'>LIKE</option></select>";
        let deleteItem='<i class="fal fa-times" onclick="this.parent().delete()"></i>';
        var srcValueElm=searchPanel.find('.dbmu-table-view-search-value-elem');
        let valueElement=srcValueElm.cloneNode(true);
        valueElement.removeClass('dbmu-table-view-search-value-elem');
        valueElement.addClass('dbmu-table-view-search-element');
        valueElement.setAttribute("name",fieldName);
        
      
        if(srcValueElm.tagName=="SELECT"){
            valueElement.find('[value="'+srcValueElm.value+'"]').setAttribute("selected","true");
        }else{
            valueElement.setAttribute("value",srcValueElm.value);
        }
        
        valueElement=valueElement.outerHTML;

        let searchElement=document.createElement("div");
        searchElement.innerHTML=deleteItem+'<span>'+fieldName+'</span>'+conditionsOperatorsElement+valueElement;

        searchContainer.appendChild(searchElement)
        searchElement.find('[operator="'+fieldName+'"] [value="'+operatorval+'"]').setAttribute("selected","selected");
               
    },
    
    searchInTable:function(btn){
        let innwindow = btn.parents('internalwindow')[0];
        let searchPanel=innwindow.find('.dbmu-table-view-search-container');
        let searchForm=innwindow.find('[searcharia="fields"]');
        let searchElements=innwindow.findAll('[searcharia="fields"] [name]');
       
        let searchText="";
        let search=[];
        searchElements.forEach(function(el){
            var field= el.attr('name');
            let fval=null;
            switch(el.attr('type')){
                case"number":
                    fval=el.value;
                break;
                case"datetime-local":
                    fval="'"+el.value.replace("T"," ")+"'";
                break;
                default:
                    fval="'"+el.value+"'";
                break;

            }
            var operation=el.parent().find('[operator="'+field+'"]').value;

            switch(operation){
                case"LIKE":
                    fval="'%"+el.value+"%'";
                break;
            }

            if(el.value !="" && el.value !=null){
                searchText=searchText +" `"+field +"` "+operation+" "+fval+" AND ";
                search.push({"val":el.value,"operator":operation,"field":field})
            }
            
        });
 
        if(searchText !=""){
            innwindow.dbconfig.searchText="WHERE "+searchText.substring(0,(searchText.length-4));
        }else{
            innwindow.dbconfig.searchText=null
        }
        
        innwindow.dbconfig.search=search;
        innwindow.find('.dbmu-table-view-pager .fa-fast-backward').click();
        searchForm.clear();
        searchPanel.style.display="none";
        
    },
    searchClear:function(btn){
        let innwindow = btn.parents('internalwindow')[0];
        let searchPanel=innwindow.find('.dbmu-table-view-search-container');
        let searchForm=innwindow.find('[searcharia="fields"]');
       

        innwindow.dbconfig.searchText=null
        innwindow.dbconfig.search={};
        DBMU.loadTableData(innwindow);
        searchForm.clear();
        searchPanel.style.display="none";
    },
    searchClose:function(btn){
        let innwindow = btn.parents('internalwindow')[0];
        let searchPanel=innwindow.find('.dbmu-table-view-search-container');
        let searchForm=innwindow.find('[searcharia="fields"]');
        searchForm.clear();
        searchPanel.style.display="none";
    },




}




